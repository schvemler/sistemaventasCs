﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace SistemasVentas
{
    class ClassAbastecimiento
    {
        /*
        public ClassAbastecimiento()
        {

        }
        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosCreate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProcedureidProduct = new MySqlParameter();
                ParProcedureidProduct.ParameterName = "ProcedureidProduct";
                ParProcedureidProduct.MySqlDbType = MySqlDbType.Int32;
                ParProcedureidProduct.Value = Class2CodigoCentral.idProduct;
                MySqlComando.Parameters.Add(ParProcedureidProduct);

                MySqlParameter ParProcedureidProveedor = new MySqlParameter();
                ParProcedureidProveedor.ParameterName = "ProcedureidProveedor";
                ParProcedureidProveedor.MySqlDbType = MySqlDbType.Int32;
                ParProcedureidProveedor.Value = Class2CodigoCentral.idProveedor;
                MySqlComando.Parameters.Add(ParProcedureidProveedor);

                MySqlParameter ParProcedureIdrubro = new MySqlParameter();
                ParProcedureIdrubro.ParameterName = "ProcedureIdrubro";
                ParProcedureIdrubro.MySqlDbType = MySqlDbType.Int32;
                ParProcedureIdrubro.Value = Class2CodigoCentral.idRubro;
                MySqlComando.Parameters.Add(ParProcedureIdrubro);

              ;

                MySqlParameter ParProductCantidad = new MySqlParameter();
                ParProductCantidad.ParameterName = "ProductCantidad";
                ParProductCantidad.MySqlDbType = MySqlDbType.Decimal;
                ParProductCantidad.Value = Convert.ToDecimal(Class2CodigoCentral.Cantidad.Replace(".", ","));
                MySqlComando.Parameters.Add(ParProductCantidad);

                MySqlParameter ParProcedurePrecioProveedor = new MySqlParameter();
                ParProcedurePrecioProveedor.ParameterName = "ProcedurePrecioProveedor";
                ParProcedurePrecioProveedor.MySqlDbType = MySqlDbType.VarChar;
                ParProcedurePrecioProveedor.Size = Class2CodigoCentral.PrecioProveedor.Length;
                ParProcedurePrecioProveedor.Value = Class2CodigoCentral.PrecioProveedor.Replace(".", ",");
                MySqlComando.Parameters.Add(ParProcedurePrecioProveedor);

                MySqlParameter ParProductPrecioVenta = new MySqlParameter();
                ParProductPrecioVenta.ParameterName = "ProductPrecioVenta";
                ParProductPrecioVenta.MySqlDbType = MySqlDbType.Decimal;
                ParProductPrecioVenta.Value = Convert.ToDecimal(Class2CodigoCentral.PrecioVenta.Replace(".", ","));
                MySqlComando.Parameters.Add(ParProductPrecioVenta);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateFull()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosPaginateFull";
                MySqlComando.CommandType = CommandType.StoredProcedure;


                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);


                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateFacturado()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosPaginateFacturado";
                MySqlComando.CommandType = CommandType.StoredProcedure;


                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);


                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginatePorFacturar()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosPaginateSinFacturar";
                MySqlComando.CommandType = CommandType.StoredProcedure;


                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);


                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginatePorRealizar()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosPaginatePorRealizar";
                MySqlComando.CommandType = CommandType.StoredProcedure;


                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);


                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateRealizado()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosPaginateRealizado";
                MySqlComando.CommandType = CommandType.StoredProcedure;


                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);


                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static DataTable IndexAbastecimientoFull()
        {
            DataTable TablaDatos = new DataTable("PedidosIndexFull");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosIndexFull";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexAbastecimientoPorFacturar()
        {
            DataTable TablaDatos = new DataTable("PedidosIndexPorFacturar");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosIndexPorFacturar";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexAbastecimientoFacturado()
        {
            DataTable TablaDatos = new DataTable("PedidosIndexFacturados");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosIndexFacturados";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexAbastecimientoPorRealizar()
        {
            DataTable TablaDatos = new DataTable("PedidosIndexPorRealizar");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosIndexPorRealizar";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexAbastecimientoRealizado()
        {
            DataTable TablaDatos = new DataTable("PedidosIndexRealizados");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosIndexRealizados";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable SearchAbastecimientoCodPro()
        {
            DataTable TablaDatos = new DataTable("PedidosSearchAbastecimientoCodPro");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosSearchAbastecimientoCodPro";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable SearchAbastecimientoNomProd()
        {
            DataTable TablaDatos = new DataTable("PedidosSearchAbastecimientoNomProd");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosSearchAbastecimientoNomProd";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable SearchAbastecimientoNomProv()
        {
            DataTable TablaDatos = new DataTable("PedidosSearchAbastecimientoNomProv");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosSearchAbastecimientoNomProv";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable SearchAbastecimientoCuitProv()
        {
            DataTable TablaDatos = new DataTable("PedidosSearchAbastecimientoCuitProv");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosSearchAbastecimientoCuitProv";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static void Facturar()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosFacturar";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParidPedido = new MySqlParameter();
                ParidPedido.ParameterName = "idPedido";
                ParidPedido.MySqlDbType = MySqlDbType.Int32;
                ParidPedido.Value = Class2CodigoCentral.idPedido;
                MySqlComando.Parameters.Add(ParidPedido);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void Marcar()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosMarcar";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParidPedido = new MySqlParameter();
                ParidPedido.ParameterName = "idPedido";
                ParidPedido.MySqlDbType = MySqlDbType.Int32;
                ParidPedido.Value = Class2CodigoCentral.idPedido;
                MySqlComando.Parameters.Add(ParidPedido);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void Delete()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosDelete";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParidPedido = new MySqlParameter();
                ParidPedido.ParameterName = "idPedido";
                ParidPedido.MySqlDbType = MySqlDbType.Int32;
                ParidPedido.Value = Class2CodigoCentral.idPedido;
                MySqlComando.Parameters.Add(ParidPedido);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void ValorMax()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "PedidosValormax";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "MaxidPedido";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Int32;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.idPedido = (Int32)MySqlComando.Parameters["ProcedureTotalPage"].Value;
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        */
    }
}
