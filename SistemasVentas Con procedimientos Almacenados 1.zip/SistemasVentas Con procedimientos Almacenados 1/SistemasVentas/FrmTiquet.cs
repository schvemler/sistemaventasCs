﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;

namespace SistemasVentas
{
    public partial class FrmTiquet : Form
    {
        public FrmTiquet()
        {
            InitializeComponent();
        }


        private Font printFont;
        private StreamReader streamToPrint;


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void pd_PrintPage(object sender, PrintPageEventArgs ev)
        {
            float linesPerPage = 0;
            float yPos = 0;
            int count = 0;
            float leftMargin = ev.MarginBounds.Left;
            float topMargin = ev.MarginBounds.Top;
            string line = null;

            // Calculate the number of lines per page.
            linesPerPage = ev.MarginBounds.Height /
               printFont.GetHeight(ev.Graphics);

            // Print each line of the file.
            while (count < linesPerPage &&
               ((line = streamToPrint.ReadLine()) != null))
            {
                yPos = topMargin + (count *
                   printFont.GetHeight(ev.Graphics));
                ev.Graphics.DrawString(line, printFont, Brushes.Black,
                   leftMargin, yPos, new StringFormat());
                count++;
            }

            // If more lines exist, print another page.
            if (line != null)
                ev.HasMorePages = true;
            else
                ev.HasMorePages = false;
        }

        private void FrmTiquet_Load(object sender, EventArgs e)
        {
            try
            {
                this.textBoxCostoTotal.Text = Convert.ToString(Class2CodigoCentral.subtotal);
                this.textBoxTotal.Text = Class2CodigoCentral.paga;
                this.textBoxCambio.Text = Convert.ToString(Convert.ToDecimal(Class2CodigoCentral.paga) - Class2CodigoCentral.subtotal);
                this.richTextBox1.Text = Class2CodigoCentral.linea;
            }
            catch { }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                streamToPrint = new StreamReader
                   (Application.StartupPath + "\\facturas\\" + Class2CodigoCentral.fecha + "\\" + Class2CodigoCentral.fecha + "factura" + Convert.ToString(Class2CodigoCentral.MaxIdFactura) + ".txt");
                try
                {
                    printFont = new Font("Arial", 10);
                    PrintDocument pd = new PrintDocument();
                    pd.PrintPage += new PrintPageEventHandler
                       (this.pd_PrintPage);
                    pd.Print();
                }
                finally
                {
                    streamToPrint.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.Close();
        }
    }
}
