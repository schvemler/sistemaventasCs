﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;


namespace SistemasVentas
{
    class DTickets
    {
        public DTickets()
        {


        }



        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {
            try
            {
                Conectar();
                MySqlCommand crear = new MySqlCommand();
                crear.Connection = conectarbase;
                string comando;
                comando = ("INSERT INTO ticketventa " +
                    "(idfactura," +
                    "costo," +
                    " pagado," +
                    "idcontrol)" +
                    " VALUES (" +
                    Class2CodigoCentral.idFacturas + ",'" +
                    Convert.ToString(Class2CodigoCentral.costo).Replace(",", ".") + "','" +
                    Class2CodigoCentral.paga.Replace(",", ".") + "'," +
                    Class2CodigoCentral.tiempo + ");");

                crear.CommandText = comando;
                crear.ExecuteNonQuery();
                Desconectar();


                Class2CodigoCentral.conteoErrores = false;
                Class2CodigoCentral.mensajeError = "FACTURA GUARDADA";

            }
            catch
            {
                Class2CodigoCentral.mensajeError = "no se ha podido guardar datos";
                Class2CodigoCentral.conteoErrores = true;
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }


        }
        public static void PaginateTodas()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(*) FROM ticketventa";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable IndexTodas()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT" +
                    " fecha as 'EMITIDO'," +
                    " costo as 'COSTO'," +
                    " pagado as 'ABONADO'," +
                    " vuelto as 'VUELTO'" +
                    " FROM ticketventa" +
                    " ORDER BY EMITIDO DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");
                index.CommandText = comando;
                index.ExecuteNonQuery();
                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateEstadisticasDiarias()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(date(fecha))) FROM ticketventa";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable EstadisticasDiarias()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT " +
                    "  DATE(fecha) as 'FECHA DE LA EMISIÓN', " +
                    "  SUM(costo) as 'COSTO TOTAL', " +
                    "  SUM(pagado) as 'TOTAL DE EFECTIVO ABONADO', " +
                    "  SUM(vuelto) as 'CAMBIO TOTAL' " +
                    " FROM ticketventa GROUP BY DATE( ticketventa.fecha) DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");
                index.CommandText = comando;
                index.ExecuteNonQuery();
                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateEstadisticasMensuales()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(month(fecha))) FROM ticketventa";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable EstadisticasMensuales()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT " +
                    "  MONTH(fecha) as 'MES DE LA EMISIÓN', " +
                    "  YEAR(fecha) as 'AÑO', " +
                    "  SUM(costo) as 'COSTO TOTAL', " +
                    "  SUM(pagado) as 'TOTAL DE EFECTIVO ABONADO', " +
                    "  SUM(vuelto) as 'CAMBIO TOTAL' " +
                    " FROM ticketventa GROUP BY MONTH( ticketventa.fecha) DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");
                index.CommandText = comando;
                index.ExecuteNonQuery();
                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateEstadisticasAnuales()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(YEAR(fecha))) FROM ticketventa";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable EstadisticasAnuales()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT " +
                    "  YEAR(fecha) as 'AÑO DE LA EMISIÓN', " +
                    "  SUM(costo) as 'COSTO TOTAL', " +
                    "  SUM(pagado) as 'TOTAL DE EFECTIVO ABONADO', " +
                    "  SUM(vuelto) as 'CAMBIO TOTAL' " +
                    " FROM ticketventa GROUP BY YEAR( ticketventa.fecha) DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");
                index.CommandText = comando;
                index.ExecuteNonQuery();
                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }

        public static void Conteo()
        {
            try
            {
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(*) FROM ticketventa";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.totaltickets = registros;


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }

    }
}