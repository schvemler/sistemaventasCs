﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace SistemasVentas
{
    class ClassProductos
    {
        public ClassProductos()
        {

        }
        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosCreate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProductName = new MySqlParameter();
                ParProductName.ParameterName = "ProductName";
                ParProductName.MySqlDbType = MySqlDbType.VarChar;
                ParProductName.Size = Class2CodigoCentral.ProductName.Length;
                ParProductName.Value = Class2CodigoCentral.ProductName;
                MySqlComando.Parameters.Add(ParProductName);

                MySqlParameter ParProductCodigo = new MySqlParameter();
                ParProductCodigo.ParameterName = "ProductCodigo";
                ParProductCodigo.MySqlDbType = MySqlDbType.VarChar;
                ParProductCodigo.Size = Class2CodigoCentral.ProductCodigo.Length;
                ParProductCodigo.Value = Class2CodigoCentral.ProductCodigo;
                MySqlComando.Parameters.Add(ParProductCodigo);

                MySqlParameter ParProcedureIdrubro = new MySqlParameter();
                ParProcedureIdrubro.ParameterName = "ProcedureIdrubro";
                ParProcedureIdrubro.MySqlDbType = MySqlDbType.Int32;
                ParProcedureIdrubro.Value = Class2CodigoCentral.idRubro;
                MySqlComando.Parameters.Add(ParProcedureIdrubro);

                MySqlParameter ParProductCantidad = new MySqlParameter();
                ParProductCantidad.ParameterName = "ProductCantidad";
                ParProductCantidad.MySqlDbType = MySqlDbType.VarChar;
                ParProductCantidad.Size = Class2CodigoCentral.Cantidad.Length;
                ParProductCantidad.Value = Class2CodigoCentral.Cantidad.Replace(",", ".");
                MySqlComando.Parameters.Add(ParProductCantidad);

                MySqlParameter ParProductPrecioCompra = new MySqlParameter();
                ParProductPrecioCompra.ParameterName = "ProductPrecioCompra";
                ParProductPrecioCompra.MySqlDbType = MySqlDbType.VarChar;
                ParProductPrecioCompra.Size = Class2CodigoCentral.PrecioCompra.Length;
                ParProductPrecioCompra.Value = Class2CodigoCentral.PrecioCompra.Replace(",", ".");
                MySqlComando.Parameters.Add(ParProductPrecioCompra);

                MySqlParameter ParProductPrecioVenta = new MySqlParameter();
                ParProductPrecioVenta.ParameterName = "ProductPrecioVenta";
                ParProductPrecioVenta.MySqlDbType = MySqlDbType.VarChar;
                ParProductPrecioVenta.Size = Class2CodigoCentral.PrecioVenta.Length;
                ParProductPrecioVenta.Value = Class2CodigoCentral.PrecioVenta.Replace(",", ".");
                MySqlComando.Parameters.Add(ParProductPrecioVenta);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void Update()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosUpdate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProductName = new MySqlParameter();
                ParProductName.ParameterName = "ProductName";
                ParProductName.MySqlDbType = MySqlDbType.VarChar;
                ParProductName.Size = Class2CodigoCentral.ProductName.Length;
                ParProductName.Value = Class2CodigoCentral.ProductName;
                MySqlComando.Parameters.Add(ParProductName);

                MySqlParameter ParProductCodigo = new MySqlParameter();
                ParProductCodigo.ParameterName = "ProductCodigo";
                ParProductCodigo.MySqlDbType = MySqlDbType.VarChar;
                ParProductCodigo.Size = Class2CodigoCentral.ProductCodigo.Length;
                ParProductCodigo.Value = Class2CodigoCentral.ProductCodigo;
                MySqlComando.Parameters.Add(ParProductCodigo);

                MySqlParameter ParIdproduct = new MySqlParameter();
                ParIdproduct.ParameterName = "idProduct";
                ParIdproduct.MySqlDbType = MySqlDbType.Int32;
                ParIdproduct.Value = Class2CodigoCentral.idProduct;
                MySqlComando.Parameters.Add(ParIdproduct);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void Delete()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosDelete";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParIdproduct = new MySqlParameter();
                ParIdproduct.ParameterName = "idProduct";
                ParIdproduct.MySqlDbType = MySqlDbType.Int32;
                ParIdproduct.Value = Class2CodigoCentral.idProduct;
                MySqlComando.Parameters.Add(ParIdproduct);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void Paginate()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductPaginate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateStock()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductPaginateStock";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateSinStock()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductPaginateSinStock";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateNullFecha()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductPaginateNullFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateOldecha()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductPaginateOldFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;


                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);


                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateNewFecha()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductPaginateNewFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;



                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);




                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static DataTable Index()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndex";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexStock()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndexStock";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexSinStock()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndexSinStock";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexOldFecha()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndexOldFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);



                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexNewFecha()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndexNewFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);


                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexNullFecha()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndexNullFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable IndexUltimos()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndexUltimos";
                MySqlComando.CommandType = CommandType.StoredProcedure;


                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable SearchName()
        {
            DataTable TablaDatos = new DataTable("SystemSearch");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductSearchName";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable SearchCodigo()
        {
            DataTable TablaDatos = new DataTable("SystemSearch");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductSearchCod";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static void SearchIfExist()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosSearchIfExist";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProductCodigo = new MySqlParameter();
                ParProductCodigo.ParameterName = "ProductCodigo";
                ParProductCodigo.MySqlDbType = MySqlDbType.VarChar;
                ParProductCodigo.Size = Class2CodigoCentral.ProductCodigo.Length;
                ParProductCodigo.Value = Class2CodigoCentral.ProductCodigo;
                MySqlComando.Parameters.Add(ParProductCodigo);

                MySqlParameter Parexistencia = new MySqlParameter();
                Parexistencia.ParameterName = "existencia";
                Parexistencia.MySqlDbType = MySqlDbType.Int32;
                Parexistencia.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(Parexistencia);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.existencia = Convert.ToBoolean((Int32)MySqlComando.Parameters["existencia"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        /*
        public static void UpdateStockVenta()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosUpdateCantidad";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParidProduct = new MySqlParameter();
                ParidProduct.ParameterName = "idProduct";
                ParidProduct.MySqlDbType = MySqlDbType.Int32;
                ParidProduct.Value = Class2CodigoCentral.idProduct;
                MySqlComando.Parameters.Add(ParidProduct);

                MySqlParameter ParProductCantidad = new MySqlParameter();
                ParProductCantidad.ParameterName = "stock";
                ParProductCantidad.MySqlDbType = MySqlDbType.VarChar;
                ParProductCantidad.Size = Class2CodigoCentral.Cantidad.Length;
                ParProductCantidad.Value = Class2CodigoCentral.Cantidad.Replace(",", ".");
                MySqlComando.Parameters.Add(ParProductCantidad);


                MySqlComando.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }

        public static void UpdateStock()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosUpdateCantidadSimple";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParidProduct = new MySqlParameter();
                ParidProduct.ParameterName = "idProduct";
                ParidProduct.MySqlDbType = MySqlDbType.Int32;
                ParidProduct.Value = Class2CodigoCentral.idProduct;
                MySqlComando.Parameters.Add(ParidProduct);

                MySqlParameter ParProductCantidad = new MySqlParameter();
                ParProductCantidad.ParameterName = "stock";
                ParProductCantidad.MySqlDbType = MySqlDbType.VarChar;
                ParProductCantidad.Size = Class2CodigoCentral.Cantidad.Length;
                ParProductCantidad.Value = Class2CodigoCentral.Cantidad.Replace(",", ".");
                MySqlComando.Parameters.Add(ParProductCantidad);


                MySqlComando.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        */
        public static DataTable SearchNameVenta()
        {
            DataTable TablaDatos = new DataTable("SystemSearchVenta");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductSearchNameVenta";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static DataTable SearchCodigoVenta()
        {
            DataTable TablaDatos = new DataTable("SystemSearch");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductSearchCodVenta";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static void UpdatePrecio()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosUpdatePrecio";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProductPrecioCompra = new MySqlParameter();
                ParProductPrecioCompra.ParameterName = "ProductPrecioCompra";
                ParProductPrecioCompra.MySqlDbType = MySqlDbType.VarChar;
                ParProductPrecioCompra.Size = Class2CodigoCentral.PrecioCompra.Length;
                ParProductPrecioCompra.Value = Class2CodigoCentral.PrecioCompra.Replace(",", ".");
                MySqlComando.Parameters.Add(ParProductPrecioCompra);

                MySqlParameter ParProductPrecioVenta = new MySqlParameter();
                ParProductPrecioVenta.ParameterName = "ProductPrecioVenta";
                ParProductPrecioVenta.MySqlDbType = MySqlDbType.VarChar;
                ParProductPrecioVenta.Size = Class2CodigoCentral.PrecioVenta.Length;
                ParProductPrecioVenta.Value = Class2CodigoCentral.PrecioVenta.Replace(",", ".");
                MySqlComando.Parameters.Add(ParProductPrecioVenta);

                MySqlParameter ParIdproduct = new MySqlParameter();
                ParIdproduct.ParameterName = "idProduct";
                ParIdproduct.MySqlDbType = MySqlDbType.Int32;
                ParIdproduct.Value = Class2CodigoCentral.idProduct;
                MySqlComando.Parameters.Add(ParIdproduct);



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void UpdateFecha()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductosUpdateFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void ConteoTotal()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductConteo";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotal";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.totalproductos = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotal"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void ConteoStock()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductConteoStock";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotal";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.totalproductos = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotal"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void ConteoSinStock()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductConteoSinStock";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotal";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.totalproductos = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotal"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void ConteoNullFecha()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductConteoNullFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotal";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.totalproductos = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotal"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void ConteoOldFecha()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductConteoOldFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotal";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.totalproductos = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotal"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void ConteoNewFecha()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductConteoNewFecha";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotal";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.totalproductos = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotal"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
    }
}
