﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.IO;

namespace SistemasVentas
{
    class DReportes
    {
        public DReportes()
        {
        }
        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {

            try
            {
                Conectar();
                MySqlCommand crear = new MySqlCommand();
                crear.Connection = conectarbase;
                string comando = ("INSERT INTO reportes " +
                    "(detalles, " +
                    "idcontrol)" +
                    " VALUES ('" +
                    Class2CodigoCentral.ReporteDetails + "," +
                    Class2CodigoCentral.tiempo + ");");

                crear.CommandText = comando;
                crear.ExecuteNonQuery();
                Desconectar();


                Class2CodigoCentral.conteoErrores = false;
                Class2CodigoCentral.mensajeError = "REPORTE GUARDADO";

            }
            catch
            {
                Class2CodigoCentral.mensajeError = "no se ha podido guardar datos";
                Class2CodigoCentral.conteoErrores = true;
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }


        }
        public static void ValorMax()
        {
            try
            {

                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT MAX(id) FROM reportes";
                int registros;
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.MaxIdReporte = registros;


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static DataTable IndexUltimos()
        {
            DataTable TablaDatos = new DataTable("ReportesIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                string comando;
                comando = ("SELECT" +
                    " id as 'ID', " +
                    " detalles as 'DETALLES', " +
                    " fecha as 'FECHA' " +
                    " FROM reportes" +
                    " ORDER BY ID DESC LIMIT 100 OFFSET 0;");

                index.CommandText = comando;
                index.ExecuteNonQuery();



                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
                TablaDatos = null;
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void CrearArchivoFactura()
        {
            Class2CodigoCentral.FechaActual();
            try
            {
                //si no existe la carpeta temporal la creamos 
                if (!(Directory.Exists(Application.StartupPath + "\\facturas")))
                {
                    Directory.CreateDirectory(Application.StartupPath + "\\facturas");
                }
            }
            catch { }
            try
            {
                //si no existe la carpeta temporal la creamos 
                if (!(Directory.Exists(Application.StartupPath + "\\facturas\\" + Class2CodigoCentral.fecha)))
                {
                    Directory.CreateDirectory(Application.StartupPath + "\\facturas\\" + Class2CodigoCentral.fecha);
                }
            }
            catch { }
            try
            {

                StreamWriter ServidorBaseDeDatos = File.CreateText(Application.StartupPath + "\\facturas\\" + Class2CodigoCentral.fecha + "\\" + Class2CodigoCentral.fecha + "factura" + Convert.ToString(Class2CodigoCentral.MaxIdFactura) + ".txt");
                ServidorBaseDeDatos.Flush();

                ServidorBaseDeDatos.Close();
            }
            catch { }


        }
        public static void EspacioLineaFactura1()
        {
            Class2CodigoCentral.espacio = " ";
            int cant = Convert.ToInt32(Class2CodigoCentral.elemento.Length);
            for (int fila = 0; fila < (30 - cant); fila++)
            {
                Class2CodigoCentral.espacio = Class2CodigoCentral.espacio + " ";
            }
        }
        public static void EspacioLineaFactura2()
        {
            Class2CodigoCentral.espacio = " ";
            int cant = Convert.ToInt32(Class2CodigoCentral.elemento.Length);
            for (int fila = 0; fila < (10 - cant); fila++)
            {
                Class2CodigoCentral.espacio = Class2CodigoCentral.espacio + " ";
            }
        }
        public static void EscribirlineaFactura()
        {
            try
            {
                StreamWriter agregadoServidorBaseDeDatos = File.AppendText(Application.StartupPath + "\\facturas\\" + Class2CodigoCentral.fecha + "\\" + Class2CodigoCentral.fecha + "factura" + Convert.ToString(Class2CodigoCentral.MaxIdFactura) + ".txt");// en el
                //escribimos.
                agregadoServidorBaseDeDatos.WriteLine(Class2CodigoCentral.linea);
                agregadoServidorBaseDeDatos.Flush();
                //Cerramos
                agregadoServidorBaseDeDatos.Close();
            }
            catch { }
        }
        public static void CrearArchivoReporte()
        {
            Class2CodigoCentral.FechaActual();
            try
            {
                //si no existe la carpeta temporal la creamos 
                if (!(Directory.Exists(Application.StartupPath + "\\Reportes")))
                {
                    Directory.CreateDirectory(Application.StartupPath + "\\Reportes");
                }
            }
            catch { }
            try
            {
                //si no existe la carpeta temporal la creamos la sub carpeta con la fecha
                if (!(Directory.Exists(Application.StartupPath + "\\Reportes\\" + Class2CodigoCentral.fecha)))
                {
                    Directory.CreateDirectory(Application.StartupPath + "\\Reportes\\" + Class2CodigoCentral.fecha);
                }
            }
            catch { }
            try
            {
                //si no existe el archivo, lo creamos para insertarlo en la carpeta
                StreamWriter ServidorBaseDeDatos = File.CreateText(Application.StartupPath + "\\Reportes\\" + Class2CodigoCentral.fecha + "\\" + Class2CodigoCentral.fecha + Class2CodigoCentral.hora + "Reporte" + Class2CodigoCentral.MaxIdReporte + ".txt");
                ServidorBaseDeDatos.Flush();

                ServidorBaseDeDatos.Close();
            }
            catch { }


        }
        public static void EscribirlineaReporte()
        {
            try
            {
                StreamWriter agregadoServidorBaseDeDatos = File.AppendText(Application.StartupPath + "\\Reportes\\" + Class2CodigoCentral.fecha + "\\" + Class2CodigoCentral.fecha + Class2CodigoCentral.hora + "Reporte" + Class2CodigoCentral.MaxIdReporte + ".txt");
                //escribimos.
                agregadoServidorBaseDeDatos.WriteLine(Class2CodigoCentral.linea);
                agregadoServidorBaseDeDatos.Flush();
                //Cerramos
                agregadoServidorBaseDeDatos.Close();
            }
            catch { }
        }
        public static void CargarReporte()
        {
            try
            {
                Class2CodigoCentral.linea = File.ReadAllText(Application.StartupPath + "\\Reportes\\" + Class2CodigoCentral.fecha + "\\" + Class2CodigoCentral.fecha + Class2CodigoCentral.hora + "Reporte" + Class2CodigoCentral.MaxIdReporte + ".txt");
            }
            catch
            {
                Class2CodigoCentral.linea = "NO EXISTE EL REPORTE";
            }

        }

        public static void CantidadTotalDeTickets()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                int registros;
                Conectar();
                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT count(idfactura) FROM ticketventa";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }
            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }
        }
        public static void TotalFacturasDeVenta()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT count(id) FROM facturas where compra=false";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void TotalFacturasDeCompra()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT count(id) FROM facturas where compra=true";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void TotalCantidadVentas()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(cantidad) FROM compraventa where compra=false";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void TotalCantidadCompras()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(cantidad) FROM compraventa where compra=true";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void TotalCompras()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(total) FROM compraventa where compra=true";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }

        }
        public static void TotalVentas()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(total) FROM compraventa where compra=false";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }

        public static void CantidadTicketsDelDia()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT count(idfactura) FROM ticketventa where fecha like CONCAT('%','" + Class2CodigoCentral.fecha + "','%')";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void FacturasDeVentaDelDia()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT count(id) FROM facturas where compra=false AND fecha like CONCAT('%','" + Class2CodigoCentral.fecha + "','%')";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void FacturasDeCompraDelDia()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT count(id) FROM facturas where compra=true AND fecha like CONCAT('%','" + Class2CodigoCentral.fecha + "','%')";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void CantidadVentasDelDia()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(cantidad) FROM compraventa where compra=false AND fecha like CONCAT('%','" + Class2CodigoCentral.fecha + "','%')";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void CantidadComprasDelDia()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(cantidad) FROM compraventa where compra=true AND fecha like CONCAT('%','" + Class2CodigoCentral.fecha + "','%')";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void TotalComprasDelDia()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(total) FROM compraventa where compra=true AND fecha like CONCAT('" + Class2CodigoCentral.fecha + "','%')";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void TotalVentasDelDia()
        {
            try
            {
                Class2CodigoCentral.FechaActual();
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT SUM(total) FROM compraventa where compra=false AND fecha like CONCAT('%','" + Class2CodigoCentral.fecha + "','%')";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.Reporte = Convert.ToString(registros);
            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

        }
        public static void reportediario()
        {
            Class2CodigoCentral.FechaActual();
            Class2CodigoCentral.linea = "REPORTE DE VENTAS DEL DÍA " + Class2CodigoCentral.fecha + "\n" + "\n";

            CantidadTicketsDelDia();
            Class2CodigoCentral.linea = Class2CodigoCentral.linea + "TICKETS EMITIDOS: " + Class2CodigoCentral.Reporte + "\n";
            FacturasDeVentaDelDia();
            Class2CodigoCentral.linea = Class2CodigoCentral.linea + "FACTURAS DE VENTA: " + Class2CodigoCentral.Reporte + "\n";
            FacturasDeCompraDelDia();
            Class2CodigoCentral.linea = Class2CodigoCentral.linea + "FACTURAS DE COMPRA: " + Class2CodigoCentral.Reporte + "\n";
            CantidadVentasDelDia();
            Class2CodigoCentral.linea = Class2CodigoCentral.linea + "CANTIDAD PRODUCTOS VENDIDOS: " + Class2CodigoCentral.Reporte + "\n";
            TotalVentasDelDia();
            Class2CodigoCentral.linea = Class2CodigoCentral.linea + "DINERO OBTENIDO POR VENTAS: $" + Class2CodigoCentral.Reporte + "\n";
            CantidadComprasDelDia();
            Class2CodigoCentral.linea = Class2CodigoCentral.linea + "PRODUCTOS ADQUIRIDOS PARA ABASTECIMIENTO: " + Class2CodigoCentral.Reporte + "\n";
            TotalComprasDelDia();
            Class2CodigoCentral.linea = Class2CodigoCentral.linea + "DINERO UTILIZADO PARA ADQUIRIR PRODUCTOS: $" + Class2CodigoCentral.Reporte + "\n";





        }
    }
}
