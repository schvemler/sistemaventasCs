﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace SistemasVentas
{
    public partial class FrmProductUpdate : Form
    {
        public FrmProductUpdate()
        {
            InitializeComponent();
        }
        private void Asig()
        {
            try
            {
                Class2CodigoCentral.ProductName = textBoxName.Text;
                Class2CodigoCentral.ProductCodigo = textBoxCodigo.Text;

            }
            catch { }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            Asig();


            if (Class2CodigoCentral.ProductName == null || Class2CodigoCentral.ProductName == String.Empty)
            {
                MessageBox.Show("FALTÓ COMPLETAR EL CAMPO 'NOMBRE'");
                textBoxName.Focus();
            }
            else
            {
                ClassProductos.Update();
                MessageBox.Show(Class2CodigoCentral.mensajeError);
                if (Class2CodigoCentral.conteoErrores == false)
                {
                    this.Close();
                }
            }



        }



        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmProductUpdate_Load(object sender, EventArgs e)
        {
            
            textBoxName.Text = Class2CodigoCentral.ProductName;

            textBoxCodigo.Text = Class2CodigoCentral.ProductCodigo;
        }

        private void textBoxName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                textBoxCodigo.Focus();
            }
        }
        private void textBoxCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                BtnSave.PerformClick();
            }
        }
    }
}
