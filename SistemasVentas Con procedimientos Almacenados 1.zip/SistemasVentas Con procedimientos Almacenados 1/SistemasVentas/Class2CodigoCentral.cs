﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.IO;
namespace SistemasVentas
{
    class Class2CodigoCentral
    {
        public static Boolean conteoErrores, conexion, existencia, vendido;
        //Errores
        public static string FacturaDetails, mensajeError, Cantidad, busqueda, fecha, hora, paga, dia, mes, año, Reporte, linea, elemento, espacio, FechaR, ReporteDetails, RubroNombre;
        //Categoy variables
        public static string PrecioVenta, PrecioProveedor, ProductName, ProductCodigo, PrecioCompra;
        public static int totalproductos, totalfacturas, totalventas, totaltickets, idPedido, idProduct, idFacturas,MaxIdFactura, MaxIdReporte;
        public static int ListaProveedoresTotalPage, idRubro, PageNumber, TotalPage, tiempo, tiempo2;
        public static decimal costo, subtotal;
        //Planta Ductos variables



        public static Boolean compra, multiventa;






        //variables de uso común
        public static int LongPage = 25;
        public static void registros()
        {
            
        }

        public static void FechaActual()
        {

            DateTime fechaactual = DateTime.Now;

            if (fechaactual.Month == 1)
            {
                mes = "01";
            }
            if (fechaactual.Month == 2)
            {
                mes = "02";
            }
            if (fechaactual.Month == 3)
            {
                mes = "03";
            }
            if (fechaactual.Month == 4)
            {
                mes = "04";
            }
            if (fechaactual.Month == 5)
            {
                mes = "05";
            }
            if (fechaactual.Month == 6)
            {
                mes = "06";
            }
            if (fechaactual.Month == 7)
            {
                mes = "07";
            }
            if (fechaactual.Month == 8)
            {
                mes = "08";
            }
            if (fechaactual.Month == 9)
            {
                mes = "09";
            }
            if (fechaactual.Month > 10)
            {
                mes = Convert.ToString(fechaactual.Month);
            }

            if (fechaactual.Day == 1)
            {
                dia = "01";
            }
            if (fechaactual.Day == 2)
            {
                dia = "02";
            }
            if (fechaactual.Day == 3)
            {
                dia = "03";
            }
            if (fechaactual.Day == 4)
            {
                dia = "04";
            }
            if (fechaactual.Day == 5)
            {
                dia = "05";
            }
            if (fechaactual.Day == 6)
            {
                dia = "06";
            }
            if (fechaactual.Day == 7)
            {
                dia = "07";
            }
            if (fechaactual.Day == 8)
            {
                dia = "08";
            }
            if (fechaactual.Day == 9)
            {
                dia = "09";
            }
            if (fechaactual.Day > 10)
            {
                dia = Convert.ToString(fechaactual.Day);
            }
            año = Convert.ToString(fechaactual.Year);

            fecha = (año + "-" + mes + "-" + dia);
            hora = Convert.ToString(fechaactual.Hour) + Convert.ToString(fechaactual.Minute) + Convert.ToString(fechaactual.Second);
        }

        public static void FechaReporte()
        {

            DateTime fechaactual = Convert.ToDateTime(FechaR);

            if (fechaactual.Month == 1)
            {
                mes = "01";
            }
            if (fechaactual.Month == 2)
            {
                mes = "02";
            }
            if (fechaactual.Month == 3)
            {
                mes = "03";
            }
            if (fechaactual.Month == 4)
            {
                mes = "04";
            }
            if (fechaactual.Month == 5)
            {
                mes = "05";
            }
            if (fechaactual.Month == 6)
            {
                mes = "06";
            }
            if (fechaactual.Month == 7)
            {
                mes = "07";
            }
            if (fechaactual.Month == 8)
            {
                mes = "08";
            }
            if (fechaactual.Month == 9)
            {
                mes = "09";
            }
            if (fechaactual.Month > 10)
            {
                mes = Convert.ToString(fechaactual.Month);
            }

            if (fechaactual.Day == 1)
            {
                dia = "01";
            }
            if (fechaactual.Day == 2)
            {
                dia = "02";
            }
            if (fechaactual.Day == 3)
            {
                dia = "03";
            }
            if (fechaactual.Day == 4)
            {
                dia = "04";
            }
            if (fechaactual.Day == 5)
            {
                dia = "05";
            }
            if (fechaactual.Day == 6)
            {
                dia = "06";
            }
            if (fechaactual.Day == 7)
            {
                dia = "07";
            }
            if (fechaactual.Day == 8)
            {
                dia = "08";
            }
            if (fechaactual.Day == 9)
            {
                dia = "09";
            }
            if (fechaactual.Day > 10)
            {
                dia = Convert.ToString(fechaactual.Day);
            }
            año = Convert.ToString(fechaactual.Year);

            fecha = (año + "-" + mes + "-" + dia);
            hora = Convert.ToString(fechaactual.Hour) + Convert.ToString(fechaactual.Minute) + Convert.ToString(fechaactual.Second);
        }



    }
}
