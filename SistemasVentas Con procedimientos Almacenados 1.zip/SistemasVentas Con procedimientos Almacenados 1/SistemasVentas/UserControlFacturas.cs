﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class UserControlFacturas : UserControl
    {
        public UserControlFacturas()
        {

            Class2CodigoCentral.registros();
            Class2CodigoCentral.PageNumber = 1;

            InitializeComponent();
            this.Dock = DockStyle.Fill;
            comboBox1.SelectedIndex = 2;
            Index();
        }
        private void diseño1()
        {
            try
            {

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch { }
        }

        private void diseño2()
        {
            try
            {

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            }
            catch { }
        }
        public void Index()
        {

            if (comboBox1.SelectedIndex == 0)
            {
                button2.Visible = false;
               ClassVenta.PaginateVentas();
                dataGridView1.DataSource =ClassVenta.IndexVentas();
                diseño2();
               ClassVenta.Conteo();
                lblTotal.Text = "Total: " + Convert.ToString(Class2CodigoCentral.totalventas) + " Productos vendidos";

            }

            if (comboBox1.SelectedIndex == 1)
            {
                button2.Visible = false;
                DTickets.PaginateTodas();
                dataGridView1.DataSource = DTickets.IndexTodas();
                diseño1();
                DTickets.Conteo();
                lblTotal.Text = "Total: " + Convert.ToString(Class2CodigoCentral.totaltickets) + " tickets de venta";

            }
            if (comboBox1.SelectedIndex == 2)
            {

                button2.Visible = true;
                DFacturas.PaginateTodas();
                dataGridView1.DataSource = DFacturas.IndexTodas();
                diseño1();
                DFacturas.Conteo();
                lblTotal.Text = "Total: " + Convert.ToString(Class2CodigoCentral.totalfacturas) + " Facturas";

            }


            this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
        }
        private void button1_Click(object sender, EventArgs e)
        {

            Class2CodigoCentral.registros();
            Class2CodigoCentral.PageNumber = 1;

            Index();


        }
        private void BtnNext_Click(object sender, EventArgs e)
        {

            if (Class2CodigoCentral.PageNumber < Class2CodigoCentral.TotalPage)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber + 1;

            }
            Index();
        }
        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber > 1)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber - 1;

            }
            Index();
        }




        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Index();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {

                if (comboBox1.SelectedIndex == 2)
                {
                    Class2CodigoCentral.FacturaDetails = this.dataGridView1.CurrentRow.Cells["DETALLES"].Value.ToString();
                    Class2CodigoCentral.idFacturas = Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString());
                    FormDetallesFactura detalles = new FormDetallesFactura();
                    detalles.ShowDialog();
                }

            }
            else
            {
                MessageBox.Show("No ha seleccionado ningún elemento de la lista");
            }
        }




    }
}
