﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class UserControlProductos : UserControl
    {
        public UserControlProductos()
        {
            Class2CodigoCentral.registros();
            Class2CodigoCentral.PageNumber = 1;
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            comboBox2.SelectedIndex = 0;
            comboBox1.SelectedIndex = 0;
            Index();
        }
        private void diseñ()
        {
            try
            {

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            }
            catch { }

        }
        public void Index()
        {
            
            
            //dataGridView1.Columns[0].Visible = false;
            Class2CodigoCentral.FechaActual();
            if (comboBox1.SelectedIndex == 0)
            {
                //Todos los productos
                ClassProductos.Paginate();
                ClassProductos.ConteoTotal();
                dataGridView1.DataSource = ClassProductos.Index();
                this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);

                
            }
            if (comboBox1.SelectedIndex == 1)
            {
                //Productos en stock
                ClassProductos.PaginateStock();
                ClassProductos.ConteoStock();
                dataGridView1.DataSource = ClassProductos.IndexStock();
                this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);

                
            }
            if (comboBox1.SelectedIndex == 2)
            {
                //Productos agotados
                ClassProductos.PaginateSinStock();
                ClassProductos.ConteoSinStock();
                dataGridView1.DataSource = ClassProductos.IndexSinStock();
                this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
               
            }
            if (comboBox1.SelectedIndex == 3)
            {
                //Productos Recientes
                ClassProductos.PaginateNullFecha();
                ClassProductos.ConteoNullFecha();

                dataGridView1.DataSource = ClassProductos.IndexNullFecha();
                this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
            }
            if (comboBox1.SelectedIndex == 4)
            {
                //Productos sin precios actualizados
                button2.Visible = true;
                ClassProductos.PaginateOldecha();
                ClassProductos.ConteoOldFecha();

                dataGridView1.DataSource = ClassProductos.IndexOldFecha(); this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
            }
            else
            {
                button2.Visible = false;
            }
            if (comboBox1.SelectedIndex == 5)
            {
                
                //Productos con precios actualizados
                ClassProductos.PaginateNewFecha();
                ClassProductos.ConteoNewFecha();

                dataGridView1.DataSource = ClassProductos.IndexNewFecha();
                this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
            }
            
            diseñ();
            lblTotal.Text = "Total: " + Convert.ToString(Class2CodigoCentral.totalproductos) + " "+comboBox1.Text;


        }
        public void Search()
        {
            if (comboBox2.SelectedIndex == 0)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = ClassProductos.SearchName();
                //dataGridView1.Columns[0].Visible = false;
                ClassProductos.Paginate();
                this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
            }
            if (comboBox2.SelectedIndex == 1)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = ClassProductos.SearchCodigo();
                //dataGridView1.Columns[0].Visible = false;
                ClassProductos.Paginate();
                this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
            }
            diseñ();


        }
        private void BtnAgregar_Click(object sender, EventArgs e)
        {

            FrmProductCreate create = new FrmProductCreate();
            create.ShowDialog();
            Index();


        }
        private void button1_Click(object sender, EventArgs e)
        {
            Class2CodigoCentral.PageNumber = 1;
            Index();
        }
        private void BtnNext_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber < Class2CodigoCentral.TotalPage)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber + 1;

            }
            Index();
        }
        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber > 1)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber - 1;

            }
            Index();
        }
        
        private void BtnEditar_Click(object sender, EventArgs e)
        {

            if (this.dataGridView1.Rows.Count > 1)
            {
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                Class2CodigoCentral.ProductName = this.dataGridView1.CurrentRow.Cells["NOMBRE"].Value.ToString();

                Class2CodigoCentral.ProductCodigo = this.dataGridView1.CurrentRow.Cells["CODIGO"].Value.ToString();

                FrmProductUpdate update = new FrmProductUpdate();
                update.ShowDialog();
            }
            else
            {
                MessageBox.Show("Debes seleccionar un producto para editar");

            }

            Index();
        }
        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 1)
            {
                DialogResult confirmacion = MessageBox.Show("¿Seguro deseas eliminar este producto?", "Eliminar Producto",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                if (confirmacion == DialogResult.OK)
                {

                    Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                    ClassProductos.Delete();
                    MessageBox.Show(Class2CodigoCentral.mensajeError);

                    Index();

                }
            }
            else
            {
                MessageBox.Show("Debes seleccionar una fila para eliminar");

            }


        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
            }
            catch
            {
            }
        }
        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
            }
            catch
            {
            }
        }
        private void dataGridView1_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
            }
            catch
            {
            }
        }
        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                //dataGridView2.DataSource = DListaProductosProveedores.IndexListaProveedoresXproducto();
            }
            catch
            {
            }
        }
        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
            }
            catch
            {
            }
        }
        private void tableLayoutPanel6_Paint(object sender, PaintEventArgs e)
        {

        }
        private void radioButtonNombre_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonMarca_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonCodigo_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ClassProductos.UpdateFecha();
            Index();

        }
        private void UserControlProductos_Load(object sender, EventArgs e)
        {

        }
        private void radioButtonTodos_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }
        private void radioButtonStock_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }
        private void radioButtonSinStock_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }



        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
            }
            catch
            {
            }
        }

       
        private void radioButtonNuevos_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }

        private void radioButtonSinActualizar_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            groupBox4.Text = comboBox1.Text;
            Index();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void btnActualiZarPrecios_Click(object sender, EventArgs e)
        {

            if (this.dataGridView1.Rows.Count > 1)
            {

                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                FrmActualizarPrecioCompra compra = new FrmActualizarPrecioCompra();
                compra.ShowDialog();

                FrmActualizarPrecioVenta venta = new FrmActualizarPrecioVenta();
                venta.ShowDialog();
                ClassProductos.UpdatePrecio();
                MessageBox.Show(Class2CodigoCentral.mensajeError);
                Index();
                btnActualiZarPrecios.Focus();

            }
            else
            {
                MessageBox.Show("Debes seleccionar una fila para actualizar los precios");

            }


        }

        private void textBoxSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) 
            {
                Search();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search();
        }
    }
}
