﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace SistemasVentas
{
    class ClassRubros
    {
        public ClassRubros()
        {

        }

        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "RubrosCreate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProveedorName = new MySqlParameter();
                ParProveedorName.ParameterName = "ProcedureNombre";
                ParProveedorName.MySqlDbType = MySqlDbType.VarChar;
                ParProveedorName.Size = Class2CodigoCentral.RubroName.Length;
                ParProveedorName.Value = Class2CodigoCentral.RubroName;
                MySqlComando.Parameters.Add(ParProveedorName);

                



                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void Paginate()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProveedoresPaginate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }

        public static DataTable Index()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "RubrosIndex";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }

        public static DataTable IndexDesc()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "RubrosIndexDesc";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }

        

        public static void Delete()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "RubrosDelete";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParidProveedor = new MySqlParameter();
                ParidProveedor.ParameterName = "ProvedureId";
                ParidProveedor.MySqlDbType = MySqlDbType.Int32;
                ParidProveedor.Value = Class2CodigoCentral.idProveedor;
                MySqlComando.Parameters.Add(ParidProveedor);


                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }

        public static void Update()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "RubrosUpdate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParidProveedor = new MySqlParameter();
                ParidProveedor.ParameterName = "ProvedureId";
                ParidProveedor.MySqlDbType = MySqlDbType.Int32;
                ParidProveedor.Value = Class2CodigoCentral.idRubro;
                MySqlComando.Parameters.Add(ParidProveedor);

                MySqlParameter ParProveedorName = new MySqlParameter();
                ParProveedorName.ParameterName = "ProcedureNombre";
                ParProveedorName.MySqlDbType = MySqlDbType.VarChar;
                ParProveedorName.Size = Class2CodigoCentral.RubroName.Length;
                ParProveedorName.Value = Class2CodigoCentral.RubroName;
                MySqlComando.Parameters.Add(ParProveedorName);


               
                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
                
            
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static DataTable SearchName()
        {
            DataTable TablaDatos = new DataTable("ProveedoresSearchName");
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProveedoresSearchName";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParName = new MySqlParameter();
                ParName.ParameterName = "Procedurename";
                ParName.MySqlDbType = MySqlDbType.VarChar;
                ParName.Size = Class2CodigoCentral.busqueda.Length;
                ParName.Value = Class2CodigoCentral.busqueda;
                MySqlComando.Parameters.Add(ParName);

                MySqlDataAdapter MySqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                MySqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Produccion.Buscarsistema. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
       
        public static void SearchIfExist()
        {
            Class2CodigoCentral.existencia = false;
            decimal registros;
            try
            {

                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(*) FROM proveedores WHERE cuit='" + Class2CodigoCentral.ProveedorCuit + "'";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();

                if (registros > 0)
                {
                    Class2CodigoCentral.existencia = true;
                }
                else
                {
                    Class2CodigoCentral.existencia = false;
                }

            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }

    }
}
