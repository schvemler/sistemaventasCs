﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class UserControlEstadisticas : UserControl
    {
        public UserControlEstadisticas()
        {
            InitializeComponent();
        }

        private void UserControlEstadisticas_Load(object sender, EventArgs e)
        {
            this.Dock = DockStyle.Fill;
            Class2CodigoCentral.PageNumber = 1;
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            Index();

        }
        private void diseño()
        {
            try
            {

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            catch { }
        }
        public void Index()
        {
            Class2CodigoCentral.registros();
            groupBox2.Text = "LISTADO DE " + comboBox1.Text + " " + comboBox2.Text;
            if (comboBox1.SelectedIndex == 0)
            {
                if (comboBox2.SelectedIndex == 0)
                {
                    DTickets.PaginateEstadisticasDiarias();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = DTickets.EstadisticasDiarias();
                }

                if (comboBox2.SelectedIndex == 1)
                {
                    DTickets.PaginateEstadisticasMensuales();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = DTickets.EstadisticasMensuales();
                }

                if (comboBox2.SelectedIndex == 2)
                {
                    DTickets.PaginateEstadisticasAnuales();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = DTickets.EstadisticasAnuales();
                }


            }

            if (comboBox1.SelectedIndex == 1)
            {
                if (comboBox2.SelectedIndex == 0)
                {
                    DFacturas.PaginateEstadisticasDiarias();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = DFacturas.EstadisticasDiarias();
                }

                if (comboBox2.SelectedIndex == 1)
                {
                    DFacturas.PaginateEstadisticasMensuales();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = DFacturas.EstadisticasMensuales();
                }

                if (comboBox2.SelectedIndex == 2)
                {
                    DFacturas.PaginateEstadisticasAnuales();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = DFacturas.EstadisticasAnuales();
                }

            }


            if (comboBox1.SelectedIndex == 2)
            {
                if (comboBox2.SelectedIndex == 0)
                {
                    ClassEstadisticas.PaginateEstadisticasDiariasVentas();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = ClassEstadisticas.EstadisticasDiariasVentas();
                }

                if (comboBox2.SelectedIndex == 1)
                {
                    ClassEstadisticas.PaginateEstadisticasMensualesVentas();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = ClassEstadisticas.EstadisticasMensualesVentas();
                }

                if (comboBox2.SelectedIndex == 2)
                {
                    ClassEstadisticas.PaginateEstadisticasAnualesVentas();
                    this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
                    dataGridView1.DataSource = ClassEstadisticas.EstadisticasAnualesVentas();
                }

            }



        }

        private void radioButtonDiario_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }

        private void radioButtonMensual_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }

        private void radioButtonAnual_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber > 1)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber - 1;
            }
            Index();
        }
        private void BtnNext_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber < Class2CodigoCentral.TotalPage)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber + 1;
            }
            Index();
        }
        private void radioButtonVentas_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }

        private void radioButtonCompras_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }
        private void radioButtonFacturas_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }
        private void radioButtonTickets_CheckedChanged(object sender, EventArgs e)
        {
            Index();
        }

        private void btnreportes_Click(object sender, EventArgs e)
        {
            FrmRportes reportes = new FrmRportes();
            reportes.ShowDialog();
            Index();
        }

        private void btnGenerarReportes_Click(object sender, EventArgs e)
        {
            DialogResult confirmacion = MessageBox.Show("¿Desea Generar un nuevo reporte?", "Generar Reporte",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            if (confirmacion == DialogResult.OK)
            {

                Class2CodigoCentral.ReporteDetails = "REPORTE DE OPERACIONES DIARIO";
                DReportes.reportediario();
                DReportes.Create();
                Class2CodigoCentral.FechaActual();
                DReportes.ValorMax();
                DReportes.CrearArchivoReporte();
                DReportes.EscribirlineaReporte();
                FrmRportes reportes = new FrmRportes();
                reportes.ShowDialog();
            }
            Index();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            Index();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Index();
        }
    }
}
