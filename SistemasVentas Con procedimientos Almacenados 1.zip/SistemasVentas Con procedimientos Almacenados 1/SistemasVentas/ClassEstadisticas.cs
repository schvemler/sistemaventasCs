﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace SistemasVentas
{
    class ClassEstadisticas
    {
        public ClassEstadisticas()
        {
        }
        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
   



       

        public static DataTable IndexFacturacion()
        {
            DataTable TablaDatos = new DataTable("VentasIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "VentasIndexFacturacion";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProcedureIdFactura = new MySqlParameter();
                ParProcedureIdFactura.ParameterName = "ProcedureIdFactura";
                ParProcedureIdFactura.MySqlDbType = MySqlDbType.Int32;
                ParProcedureIdFactura.Value = Class2CodigoCentral.idFacturas;
                MySqlComando.Parameters.Add(ParProcedureIdFactura);

                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateEstadisticasDiariasVentas()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(date(fecha))) FROM compraventa  WHERE compra=false";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }


        public static DataTable EstadisticasDiariasVentas()
        {
            DataTable TablaDatos = new DataTable("EstadisticasDiariasVentas");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "EstadisticasDiariasVentas";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
       

        public static void PaginateEstadisticasMensualesVentas()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(MONTH(fecha))) FROM compraventa WHERE compra=false";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable EstadisticasMensualesVentas()
        {
            DataTable TablaDatos = new DataTable("EstadisticasMensualesVentas");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "EstadisticasMensualesVentas";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
       

        public static void PaginateEstadisticasAnualesVentas()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(YEAR(fecha))) FROM compraventa WHERE compra=false";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }


        public static DataTable EstadisticasAnualesVentas()
        {
            DataTable TablaDatos = new DataTable("EstadisticasAnualesVentas");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "EstadisticasAnualesVentas";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }
      
       
       
    }
}
