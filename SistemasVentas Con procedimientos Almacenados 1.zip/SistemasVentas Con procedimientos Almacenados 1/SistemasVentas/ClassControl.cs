﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace SistemasVentas
{
    class ClassControl
    {
        public ClassControl()
        {

        }
        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {

            try
            {
                Conectar();
                MySqlCommand crear = new MySqlCommand();
                crear.Connection = conectarbase;
                string comando;
                comando = ("INSERT INTO controlador(cont)VALUES(true)");

                crear.CommandText = comando;
                crear.ExecuteNonQuery();
                Desconectar();




            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }


        }
        public static void ValorMax()
        {
            try
            {
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT MAX(id) FROM controlador";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.tiempo = registros;


            }

            catch
            {
                Class2CodigoCentral.tiempo = 0;

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }


        }
    }
}
