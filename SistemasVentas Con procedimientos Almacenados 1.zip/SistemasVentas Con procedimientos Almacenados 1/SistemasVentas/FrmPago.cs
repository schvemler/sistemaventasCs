﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmPago : Form
    {
        public FrmPago()
        {
            InitializeComponent();
        }
        public Boolean coma = false;
        public int conteo = 0;


        private void FrmPago_Load(object sender, EventArgs e)
        {
            textBoxCostoTotal.Text = Convert.ToString(Class2CodigoCentral.subtotal);
            Class2CodigoCentral.paga = textBoxTotal.Text;
        }

        private void textBoxTotal_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal total;
                total = Convert.ToDecimal(textBoxTotal.Text);
                textBoxCambio.Text = Convert.ToString(total - Class2CodigoCentral.subtotal);
                Class2CodigoCentral.paga = textBoxTotal.Text;
            }
            catch { }
        }

        private void textBoxTotal_KeyPress(object sender, KeyPressEventArgs e)
        {

            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
            else
            {
                if (e.KeyChar == 46 && coma == true)
                {
                    e.Handled = true;
                }
                else
                {
                    if (conteo > 1)
                    {
                        e.Handled = true;
                    }
                    else
                    {

                        if (coma == true)
                        {
                            conteo++;
                        }
                        e.Handled = false;
                    }

                }

            }

            if (e.KeyChar == 46)
            {
                coma = true;
            }

            if (e.KeyChar == 8)
            {
                coma = false;
                conteo = 0;
                textBoxTotal.Text = "";

            }
            if (e.KeyChar == 13)
            {
                try
                {
                    if ((Convert.ToDecimal(Class2CodigoCentral.paga.Replace(".", ",")) - Class2CodigoCentral.subtotal) >= 0)
                    {
                        this.Close();
                    }
                    else
                    {
                        coma = false;
                        conteo = 0;
                    }
                }
                catch { }



            }
        }
    }
}
