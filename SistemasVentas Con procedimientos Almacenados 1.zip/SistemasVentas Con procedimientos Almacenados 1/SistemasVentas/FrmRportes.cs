﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;


namespace SistemasVentas
{
    public partial class FrmRportes : Form
    {
        public FrmRportes()
        {
            InitializeComponent();
        }
        private Font printFont;
        private StreamReader streamToPrint;

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmRportes_Load(object sender, EventArgs e)
        {
            richTextBox1.Text = Class2CodigoCentral.linea;
            Index();
        }
        private void cargar()
        {
            if (this.dataGridView1.Rows.Count > 1)
            {
                try
                {
                    Class2CodigoCentral.MaxIdReporte = Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString());
                    Class2CodigoCentral.FechaR = this.dataGridView1.CurrentRow.Cells["FECHA"].Value.ToString();
                    Class2CodigoCentral.FechaReporte();
                    DReportes.CargarReporte();
                    richTextBox1.Text = Class2CodigoCentral.linea;
                }
                catch { }

            }
        }
        private void diseño()
        {
            try
            {

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            }
            catch { }
        }
        private void Index()
        {
            dataGridView1.DataSource = DReportes.IndexUltimos();
            diseño();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                streamToPrint = new StreamReader
                  (Application.StartupPath + "\\Reportes\\" + Class2CodigoCentral.fecha + "\\" + Class2CodigoCentral.fecha + Class2CodigoCentral.hora + "Reporte" + Class2CodigoCentral.MaxIdReporte + ".txt");
                try
                {
                    printFont = new Font("Arial", 10);
                    PrintDocument pd = new PrintDocument();
                    pd.PrintPage += new PrintPageEventHandler
                       (this.pd_PrintPage);
                    pd.Print();
                }
                finally
                {
                    streamToPrint.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }



        private void pd_PrintPage(object sender, PrintPageEventArgs ev)
        {
            float linesPerPage = 0;
            float yPos = 0;
            int count = 0;
            float leftMargin = ev.MarginBounds.Left;
            float topMargin = ev.MarginBounds.Top;
            string line = null;

            // Calculate the number of lines per page.
            linesPerPage = ev.MarginBounds.Height /
               printFont.GetHeight(ev.Graphics);

            // Print each line of the file.
            while (count < linesPerPage &&
               ((line = streamToPrint.ReadLine()) != null))
            {
                yPos = topMargin + (count *
                   printFont.GetHeight(ev.Graphics));
                ev.Graphics.DrawString(line, printFont, Brushes.Black,
                   leftMargin, yPos, new StringFormat());
                count++;
            }

            // If more lines exist, print another page.
            if (line != null)
                ev.HasMorePages = true;
            else
                ev.HasMorePages = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            cargar();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cargar();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            cargar();
        }

        private void dataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
            cargar();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            cargar();
        }
    }
}
