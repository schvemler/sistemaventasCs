﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.IO;
namespace SistemasVentas
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void tryconeccion()
        {
            Class1Coneccion.conectar();
            Class1Coneccion.tryConecction();
            if (Class2CodigoCentral.conexion == true)
            {

                comboBox1.Visible = true;


                btnNuevaVenta.Visible = true;
                btnNuevaVenta.Enabled = true;

                FrmBienvenida bienvenida = new FrmBienvenida();
                bienvenida.ShowDialog();
                timer1.Enabled = true;
                comboBox1.SelectedIndex = 0;
            }
            else
            {

                comboBox1.Visible = false;



                btnNuevaVenta.Visible = false;
                btnNuevaVenta.Enabled = false;
                FrmConexion conectar = new FrmConexion();
                conectar.ShowDialog();
            }


        }
        private void cargar()
        {
            if (comboBox1.SelectedIndex == 0)
            {
                UserControlProductos productos = new UserControlProductos();
                this.PanelContainer.Controls.Clear();
                this.PanelContainer.Controls.Add(productos);


            }
            if (comboBox1.SelectedIndex == 1)
            {
                UserControlProveedores proveedores = new UserControlProveedores();
                this.PanelContainer.Controls.Clear();
                this.PanelContainer.Controls.Add(proveedores);

            }
            if (comboBox1.SelectedIndex == 2)
            {
                UserControlFacturas facturas = new UserControlFacturas();
                this.PanelContainer.Controls.Clear();
                this.PanelContainer.Controls.Add(facturas);

            }
            if (comboBox1.SelectedIndex == 3)
            {
                UserControlEstadisticas estadisticas = new UserControlEstadisticas();
                this.PanelContainer.Controls.Clear();
                this.PanelContainer.Controls.Add(estadisticas);

            }
            Class2CodigoCentral.PageNumber = 1;


        }
        private void licencia()
        {
            ClassControl.ValorMax();
            label1.Text = Convert.ToString(Class2CodigoCentral.tiempo);
            if (Class2CodigoCentral.tiempo > 500)
            {
                timer1.Enabled = false;
                FrmFinLicencia licencia = new FrmFinLicencia();
                licencia.ShowDialog();
                Application.Exit();
            }


        }
        private void multiventa() 
        {
            if (Class2CodigoCentral.multiventa == true) 
            {
                FrmModuloVenta ventas = new FrmModuloVenta();
                ventas.ShowDialog();
                multiventa();
            }
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            tryconeccion();
            ClassControl.Create();
            licencia();
            Class2CodigoCentral.tiempo2 = 0;

        }
        private void BtnConexion_Click(object sender, EventArgs e)
        {

            FrmConexion conectar = new FrmConexion();
            conectar.ShowDialog();
            tryconeccion();


        }

        private void btnNuevaVenta_Click(object sender, EventArgs e)
        {
            Class2CodigoCentral.multiventa = false;
            FrmModuloVenta ventas = new FrmModuloVenta();
            ventas.ShowDialog();
            multiventa();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Class2CodigoCentral.tiempo2++;
            if (Class2CodigoCentral.tiempo2 >= 3600)
            {
                ClassControl.Create();
                licencia();
                Class2CodigoCentral.tiempo2 = 0;
            }



        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            cargar();
        }







    }
}
