﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmProductCreate : Form
    {
        public FrmProductCreate()
        {
            InitializeComponent();
        }
        private void Asig()
        {
            try
            {
                Class2CodigoCentral.ProductName = textBoxName.Text;
               
                Class2CodigoCentral.ProductCodigo = textBoxCodigo.Text;
               
                Class2CodigoCentral.idRubro = Convert.ToInt32(dataGridView2.CurrentRow.Cells["ID"].Value.ToString());
              

            }
            catch { }
        }
        public void Index()
        {
            dataGridView2.DefaultCellStyle.SelectionBackColor = Color.Gray;
            dataGridView1.DataSource = ClassProductos.IndexUltimos();
            dataGridView2.DataSource = ClassRubros.Index();
        }
        private void BtnSave_Click(object sender, EventArgs e)
        {
            Asig();
            if (Class2CodigoCentral.ProductName == null || Class2CodigoCentral.ProductName == String.Empty)
            {
                MessageBox.Show("FALTÓ COMPLETAR EL CAMPO 'NOMBRE'");
                textBoxName.Focus();
            }
            else
            {
                
                Class2CodigoCentral.Cantidad = "0.00";
                if (checkBox2.Checked == true)
                {

                    FrmActualizarPrecioCompra compra = new FrmActualizarPrecioCompra();
                    compra.ShowDialog();
                    FrmActualizarPrecioVenta venta = new FrmActualizarPrecioVenta();
                    venta.ShowDialog();

                }
                else
                {
                    Class2CodigoCentral.PrecioCompra = "0.00";
                    Class2CodigoCentral.PrecioVenta = "0.00";
                }
                ClassProductos.Create();
                
                textBoxName.Focus();
                if (Class2CodigoCentral.conteoErrores == true)
                {
                    MessageBox.Show(Class2CodigoCentral.mensajeError);
                }
            }
            Index();
            textBoxName.Text = "";
            textBoxCodigo.Text = "";


        }
        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
            if (e.KeyChar == 13)
            {
                if (string.IsNullOrEmpty(textBoxName.Text))
                {
                    MessageBox.Show("Debe si os is escribir el nombre del producto");
                    textBoxName.Focus();
                }
                else
                {
                    textBoxCodigo.Focus();
                }

            }
        }
      
        private void textBoxCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
            if (e.KeyChar == 13)
            {
                if (string.IsNullOrEmpty(textBoxCodigo.Text))
                {
                    MessageBox.Show("Ingrese el codigo del producto");
                    textBoxCodigo.Focus();
                }
                else
                {
                    Class2CodigoCentral.ProductCodigo = textBoxCodigo.Text;
                    ClassProductos.SearchIfExist();
                    if (Class2CodigoCentral.existencia == true)
                    {
                        MessageBox.Show("ya existe un producto registrado con este codigo, verifique la lista de productos almacenados");
                        textBoxCodigo.Focus();
                    }
                    else
                    {
                        dataGridView2.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
                        dataGridView2.Focus();
                    }
                }


            }
        }
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FrmProductCreate_Load(object sender, EventArgs e)
        {

        }
        private void FrmProductCreate_Load_1(object sender, EventArgs e)
        {
            Index();
        }

        private void dataGridView2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                BtnSave.PerformClick();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
