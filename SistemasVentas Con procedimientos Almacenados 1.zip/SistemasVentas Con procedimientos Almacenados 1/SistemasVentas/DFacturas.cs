﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace SistemasVentas
{
    class DFacturas
    {
        public DFacturas()
        {

        }
        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {

            try
            {
                Conectar();
                MySqlCommand crear = new MySqlCommand();
                crear.Connection = conectarbase;
                string comando;
                comando = ("INSERT INTO facturas " +
                "(compra," +
                " detalle," +
                "idcontrol)" +
                " VALUES (" +
                Class2CodigoCentral.compra + ",'" +
                Class2CodigoCentral.FacturaDetails + "'," +
                1 + ");");

                crear.CommandText = comando;
                crear.ExecuteNonQuery();
                Desconectar();

                Class2CodigoCentral.conteoErrores = false;
                Class2CodigoCentral.mensajeError = "FACTURA GUARDADA";

            }
            catch
            {
                Class2CodigoCentral.mensajeError = "no se ha podido guardar datos";
                Class2CodigoCentral.conteoErrores = true;
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }


        }
        public static void PaginateTodas()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(*) FROM facturas";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable IndexTodas()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT" +
                    " id as 'ID'," +
                    " fecha as 'EMITIDA'," +
                    " compra as 'COMPRA'," +
                    " detalle as 'DETALLES'" +
                    " FROM facturas" +
                    " ORDER BY ID DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");

                index.CommandText = comando;
                index.ExecuteNonQuery();



                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateCompras()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(*) FROM facturas WHERE compra=true";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable IndexCompras()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT" +
                    " id as 'ID'," +
                    " fecha as 'EMITIDA'," +
                    " compra as 'COMPRA'," +
                    " detalle as 'DETALLES'" +
                    " FROM facturas" +
                    " WHERE compra=true ORDER BY ID DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");

                index.CommandText = comando;
                index.ExecuteNonQuery();



                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateVentas()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(*) FROM facturas WHERE compra=false";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable IndexVentas()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT" +
                    " id as 'ID'," +
                    " fecha as 'EMITIDA'," +
                    " compra as 'COMPRA'," +
                    " detalle as 'DETALLES'" +
                    " FROM facturas" +
                    " WHERE compra=false ORDER BY ID DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");

                index.CommandText = comando;
                index.ExecuteNonQuery();



                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }

        

        public static void PaginateEstadisticasDiarias()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(date(fecha))) FROM facturas";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable EstadisticasDiarias()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT " +
                    "  DATE(fecha) as 'FECHA DE LA EMISIÓN', " +
                    "  COUNT(id) as 'CANTIDAD EMITIDAS' " +
                    " FROM facturas GROUP BY DATE( facturas.fecha) DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");
                index.CommandText = comando;
                index.ExecuteNonQuery();
                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateEstadisticasMensuales()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(MONTH(fecha))) FROM facturas";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable EstadisticasMensuales()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT " +
                    "  MONTH(fecha) as 'MES DE LA EMISIÓN', " +
                    "  YEAR(fecha) as 'AÑO', " +
                    "  COUNT(id) as 'CANTIDAD EMITIDAS' " +
                    " FROM facturas GROUP BY YEAR( facturas.fecha) DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");
                index.CommandText = comando;
                index.ExecuteNonQuery();
                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }
        public static void PaginateEstadisticasAnuales()
        {
            try
            {
                decimal registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(DISTINCT(YEAR(fecha))) FROM facturas";
                registros = Convert.ToDecimal(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.TotalPage = Convert.ToInt32(registros / Class2CodigoCentral.LongPage);
                if ((registros / Class2CodigoCentral.LongPage) > Class2CodigoCentral.TotalPage)
                {
                    Class2CodigoCentral.TotalPage = Class2CodigoCentral.TotalPage + 1;
                }
                if (Class2CodigoCentral.TotalPage == 0)
                {
                    Class2CodigoCentral.TotalPage = 1;
                }


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
        public static DataTable EstadisticasAnuales()
        {
            DataTable TablaDatos = new DataTable("ProveedorIndex");
            try
            {
                Conectar();
                MySqlCommand index = new MySqlCommand();
                index.Connection = conectarbase;
                int inicial;
                inicial = Class2CodigoCentral.PageNumber * Class2CodigoCentral.LongPage - Class2CodigoCentral.LongPage;
                string comando;
                comando = ("SELECT " +
                    "  YEAR(fecha) as 'AÑO DE LA EMISIÓN', " +
                    "  COUNT(id) as 'CANTIDAD EMITIDAS' " +
                    " FROM facturas GROUP BY YEAR( facturas.fecha) DESC LIMIT " + Class2CodigoCentral.LongPage + " OFFSET " + inicial + ";");
                index.CommandText = comando;
                index.ExecuteNonQuery();
                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(index);
                SqlAdaptadorDatos.Fill(TablaDatos);

                Desconectar();
            }
            catch
            {
            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }

            return TablaDatos;
        }

        public static void Conteo()
        {
            try
            {
                int registros;
                Conectar();

                MySqlCommand contar = new MySqlCommand();
                contar.Connection = conectarbase;
                contar.CommandText = "SELECT COUNT(*) FROM facturas";
                registros = Convert.ToInt32(contar.ExecuteScalar().ToString());
                contar.Dispose();
                Desconectar();
                Class2CodigoCentral.totalfacturas = registros;


            }

            catch
            {

            }
            finally
            {
                if (conectarbase.State == ConnectionState.Open)
                {
                    conectarbase.Close();
                }
            }



        }
    }
}
