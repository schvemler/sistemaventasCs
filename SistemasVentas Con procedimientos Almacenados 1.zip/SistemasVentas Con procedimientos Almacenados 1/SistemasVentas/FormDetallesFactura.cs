﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FormDetallesFactura : Form
    {
        public FormDetallesFactura()
        {
            InitializeComponent();
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormDetallesFactura_Load(object sender, EventArgs e)
        {
            labelDetalles.Text = Class2CodigoCentral.FacturaDetails;
            labelNumero.Text = Convert.ToString(Class2CodigoCentral.idFacturas);
            this.dataGridView1.DataSource =ClassVenta.IndexFacturacion();
        }
    }
}
