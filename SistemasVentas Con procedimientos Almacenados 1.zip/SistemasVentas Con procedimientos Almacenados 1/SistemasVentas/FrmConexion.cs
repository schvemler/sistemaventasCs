﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.IO;
namespace SistemasVentas
{
    public partial class FrmConexion : Form
    {
        public FrmConexion()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Index()
        {
            this.txtContraseña.PasswordChar = '*';
            try
            {
                this.txtServidor.Text = File.ReadAllText(Application.StartupPath + "\\ServidorNombre.txt");
                this.txtBaseDatos.Text = File.ReadAllText(Application.StartupPath + "\\ServidorBaseDeDatos.txt");
                this.txtUsuario.Text = File.ReadAllText(Application.StartupPath + "\\ServidorUsuario.txt");
                this.txtContraseña.Text = File.ReadAllText(Application.StartupPath + "\\ServidorContraseña.txt");



            }
            catch { }
        }

        private void btnguardar_Click(object sender, System.EventArgs e)
        {
            try
            {
                StreamWriter ServidorBaseDeDatos = File.CreateText(Application.StartupPath + "\\ServidorBaseDeDatos.txt");
                ServidorBaseDeDatos.Flush();
                //Cerramos
                ServidorBaseDeDatos.Close();
            }
            catch { }
            try
            {
                StreamWriter Contraseña = File.CreateText(Application.StartupPath + "\\ServidorContraseña.txt");
                Contraseña.Flush();
                //Cerramos
                Contraseña.Close();
            }
            catch { }
            try
            {
                StreamWriter Nombre = File.CreateText(Application.StartupPath + "\\ServidorNombre.txt");
                Nombre.Flush();
                //Cerramos
                Nombre.Close();
            }
            catch { }
            try
            {
                StreamWriter Usuario = File.CreateText(Application.StartupPath + "\\ServidorUsuario.txt");
                Usuario.Flush();
                //Cerramos
                Usuario.Close();
            }
            catch { }
            try
            {
                StreamWriter agregadoServidorNombre = File.AppendText(Application.StartupPath + "\\ServidorNombre.txt"); // en el 
                //escribimos.
                agregadoServidorNombre.Write(txtServidor.Text);
                agregadoServidorNombre.Flush();
                //Cerramos
                agregadoServidorNombre.Close();
            }
            catch { }
            try
            {
                StreamWriter agregadoServidorUsuario = File.AppendText(Application.StartupPath + "\\ServidorUsuario.txt");
                // en el
                //escribimos.
                agregadoServidorUsuario.Write(txtUsuario.Text);
                agregadoServidorUsuario.Flush();
                //Cerramos
                agregadoServidorUsuario.Close();
            }
            catch { }
            try
            {
                StreamWriter agregadoServidorContraseña = File.AppendText(Application.StartupPath + "\\ServidorContraseña.txt"); // en el 
                //escribimos.
                agregadoServidorContraseña.Write(txtContraseña.Text);
                agregadoServidorContraseña.Flush();
                //Cerramos
                agregadoServidorContraseña.Close();
            }
            catch { }
            try
            {
                StreamWriter agregadoServidorBaseDeDatos = File.AppendText(Application.StartupPath + "\\ServidorBaseDeDatos.txt"); // en el
                //escribimos.
                agregadoServidorBaseDeDatos.Write(txtBaseDatos.Text);
                agregadoServidorBaseDeDatos.Flush();
                //Cerramos
                agregadoServidorBaseDeDatos.Close();
            }
            catch { }
            Class1Coneccion.conectar();
            Class1Coneccion.tryConecction();
            if (Class2CodigoCentral.conexion == true)
            {

                MessageBox.Show("La conexión ha sido un exito");
                this.Close();

            }
            else
            {
                MessageBox.Show("La conexión ha fallado");
            }

        }
        private void txtServidor_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) { txtUsuario.Focus(); }

        }

        private void txtUsuario_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) { txtContraseña.Focus(); }
        }

        private void txtContraseña_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) { txtBaseDatos.Focus(); }
        }



        private void txtBaseDatos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) { btnguardar.PerformClick(); }
        }

        private void FrmConexion_Load(object sender, System.EventArgs e)
        {
            Index();
        }

        private void txtContraseña_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmConexion_FormClosed(object sender, FormClosedEventArgs e)
        {


        }




    }
}
