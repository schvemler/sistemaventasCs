﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.IO;

namespace SistemasVentas
{
    class Class1Coneccion
    {
        public static String DataBase;
        public Class1Coneccion()
        {

        }
        public static void conectar()
        {
            try
            {
                DataBase = "Server=" + File.ReadAllText(Application.StartupPath + "\\ServidorNombre.txt") + ";Database=" + File.ReadAllText(Application.StartupPath + "\\ServidorBaseDeDatos.txt") + ";Uid=" + File.ReadAllText(Application.StartupPath + "\\ServidorUsuario.txt") + ";Pwd=" + File.ReadAllText(Application.StartupPath + "\\ServidorContraseña.txt") + ";";
            }
            catch { }
        }
        public static void tryConecction()
        {
            MySqlConnection MySqlConexion = new MySqlConnection(Class1Coneccion.DataBase);
            try
            {

                MySqlConexion.Open();
                MySqlConexion.Close();
                Class2CodigoCentral.conexion = true;
            }
            catch
            {
                Class2CodigoCentral.conexion = false;
            }
            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

        }
    }
}
