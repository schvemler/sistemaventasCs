﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmModuloPedidos : Form
    {
        public FrmModuloPedidos()
        {
            InitializeComponent();
        }
        private void Search()
        {
            if (comboBox2.SelectedIndex == 0)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = DListaProductosProveedores.SearchCodigoPedido();


            }
            if (comboBox2.SelectedIndex == 1)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = DListaProductosProveedores.SearchNombrePedido();

            }
            if (comboBox2.SelectedIndex == 2)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = DListaProductosProveedores.SearchMarcaPedido();
            }
            diseño();



        }
        private void diseño()
        {
            try
            {
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[7].Visible = false;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            }
            catch { }
        }
        private void index()
        {
            try
            {
                dataGridView1.DataSource = DListaProductosProveedores.IndexListaDetallesproductosXproveedorFull();
                diseño();
            }
            catch
            {
                MessageBox.Show("No se ha podido cargar la lista de categorìas");

            }
        }
        private void pedidoFacturado()
        {
            Class2CodigoCentral.FacturaDetails = "REPOSICIÓN DE PRODUCTOS";
            Class2CodigoCentral.compra = true;
            DFacturas.Create();
           
            for (int fila = 1; fila < dataGridView2.Rows.Count; fila++)
            {
                Class2CodigoCentral.idProduct = Convert.ToInt32(dataGridView2.Rows[fila - 1].Cells["ID1"].Value.ToString());
                Class2CodigoCentral.idProveedor = Convert.ToInt32(dataGridView2.Rows[fila - 1].Cells["ID2"].Value.ToString());
                Class2CodigoCentral.PrecioProveedor = dataGridView2.Rows[fila - 1].Cells["PRECIO"].Value.ToString();
                Class2CodigoCentral.Cantidad = dataGridView2.Rows[fila - 1].Cells["CANT"].Value.ToString();
                ClassAbastecimiento.Create();
                ClassAbastecimiento.ValorMax();
                Class2CodigoCentral.compra = true;
                //Class2CodigoCentral.idFacturas = Class2CodigoCentral.MaxIdFactura;
                ClassAbastecimiento.Facturar();
               ClassVenta.Create();

            }
            this.Close();
            MessageBox.Show(Class2CodigoCentral.mensajeError);
        }
        private void pedidoSinfacturar()
        {
            for (int fila = 1; fila < dataGridView2.Rows.Count; fila++)
            {
                Class2CodigoCentral.idProduct = Convert.ToInt32(dataGridView2.Rows[fila - 1].Cells["ID1"].Value.ToString());
                Class2CodigoCentral.idProveedor = Convert.ToInt32(dataGridView2.Rows[fila - 1].Cells["ID2"].Value.ToString());
                Class2CodigoCentral.PrecioProveedor = dataGridView2.Rows[fila - 1].Cells["PRECIO"].Value.ToString();
                Class2CodigoCentral.Cantidad = dataGridView2.Rows[fila - 1].Cells["CANT"].Value.ToString();
                ClassAbastecimiento.Create();

            }
            MessageBox.Show(Class2CodigoCentral.mensajeError);
            this.Close();
        }
        private void FrmModuloCompras_Load(object sender, EventArgs e)
        {
            comboBox2.SelectedIndex = 0;
            index();
        }
        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonCodigo_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonMarca_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonNombre_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.dataGridView2.Rows.Count > 1)
            {
                try
                {
                    this.dataGridView2.Rows.Remove(this.dataGridView2.Rows[this.dataGridView2.CurrentRow.Index]);
                }
                catch
                {
                    MessageBox.Show("DEBE HACER CLICK SOBRE UNO DE LOS PRODUCTOS PEDIDOS PARA PODER RETIRARLO DE LA LISTA");
                }

            }
            else
            {
                MessageBox.Show("NO SE PUEDE REALIZAR ESTA OPERACIÓN SIN NINGÚN PRODUCTO EN LA LISTA ");

            }


        }
        private void textBoxSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
            if (e.KeyChar == 13)
            {


                textBoxCantidad.Enabled = true;
                textBoxCantidad.Focus();
                Search();
            }
        }
        private void textBoxCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
            if (e.KeyChar == 13)
            {
                try
                {
                    Class2CodigoCentral.ProductName = dataGridView1.CurrentRow.Cells["PRODUCTO"].Value.ToString();
                    Class2CodigoCentral.PrecioProveedor = dataGridView1.CurrentRow.Cells["PRECIO"].Value.ToString();
                    if (string.IsNullOrEmpty(textBoxCantidad.Text))
                    {
                        Class2CodigoCentral.Cantidad = "1";
                    }
                    else
                    {
                        Class2CodigoCentral.Cantidad = textBoxCantidad.Text;
                    }
                    Class2CodigoCentral.ProductCodigo = dataGridView1.CurrentRow.Cells["CODIGO"].Value.ToString();
                    Class2CodigoCentral.RubroName = dataGridView1.CurrentRow.Cells["PROVEEDORES"].Value.ToString();
                    Class2CodigoCentral.idProveedor = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID2"].Value.ToString());
                    Class2CodigoCentral.idProduct = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value.ToString());

                    decimal total = Convert.ToDecimal(Class2CodigoCentral.PrecioProveedor.Replace(".", ",")) * Convert.ToDecimal(Class2CodigoCentral.Cantidad.Replace(".", ","));

                    dataGridView2.Rows.Add(
                        Class2CodigoCentral.ProductName,
                        Class2CodigoCentral.PrecioProveedor,
                        Class2CodigoCentral.Cantidad,
                        Class2CodigoCentral.ProductCodigo,
                        Class2CodigoCentral.RubroName,
                        Convert.ToString(total),
                        Class2CodigoCentral.idProduct,
                        Class2CodigoCentral.idProveedor);
                    textBoxSearch.Focus();
                    textBoxCantidad.Enabled = false;
                }
                catch
                {
                    textBoxSearch.Focus();
                }

            }
        }

        private void buttonGuardarFacturar_Click(object sender, EventArgs e)
        {

            if (this.dataGridView2.Rows.Count > 1)
            {
                pedidoFacturado();

            }
            else
            {
                MessageBox.Show("AGREGUE PRIMERO LOS PRODUCTOS ANTES DE REALIZAR EL PEDIDO");
            }
        }
        private void buttonGuardar_Click(object sender, EventArgs e)
        {
            if (this.dataGridView2.Rows.Count > 1)
            {
                pedidoSinfacturar();
            }
            else
            {
                MessageBox.Show("AGREGUE PRIMERO LOS PRODUCTOS ANTES DE REALIZAR EL PEDIDO");

            }

        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
