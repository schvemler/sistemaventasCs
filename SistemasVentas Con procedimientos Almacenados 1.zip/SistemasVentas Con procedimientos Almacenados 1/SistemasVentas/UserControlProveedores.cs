﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.IO;



namespace SistemasVentas
{
    public partial class UserControlProveedores : UserControl
    {
        public UserControlProveedores()
        {
            Class2CodigoCentral.registros();
            Class2CodigoCentral.PageNumber = 1;
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            Index();
            

        }
        private void diseño()
        {
            try
            {

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }
            catch { }
        }
        public void Index()
        {
            DProveedores.Paginate();
            this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
            dataGridView1.DataSource = ClassRubros.Index();
            //dataGridView1.Columns[0].Visible = false;


            try
            {

            }
            catch
            {
                MessageBox.Show("No se ha podido cargar ningún elemento");

            }
            diseño();
        }


        public void Search()
        {
            Class2CodigoCentral.busqueda = textBoxSearch.Text;
            DProveedores.Paginate();
            this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
            dataGridView1.DataSource = DProveedores.SearchEmail();
            //dataGridView1.Columns[0].Visible = false;
            diseño();

        }


        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            FrmProveedorCreate create = new FrmProveedorCreate();
            create.ShowDialog();
            Index();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class2CodigoCentral.PageNumber = 1;
            Index();
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber < Class2CodigoCentral.TotalPage)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber + 1;

            }
            Index();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber > 1)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber - 1;

            }
            Index();
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dataGridView1.Rows.Count > 0)
                {
                    Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                    Class2CodigoCentral.RubroName = this.dataGridView1.CurrentRow.Cells["NOMBRE"].Value.ToString();
     
                    FrmProveedoresUpdate update = new FrmProveedoresUpdate();
                    update.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Debes seleccionar una fila para editar");
                }
            }
            catch
            {
                MessageBox.Show("No existe ningún elemento en la lista");
            }
            Index();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dataGridView1.Rows.Count > 0)
                {
                    DialogResult confirmacion = MessageBox.Show("¿Seguro deseas eliminar este distribuidor?", "Eliminar distribuidor",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                    if (confirmacion == DialogResult.OK)
                    {

                        Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                        ClassRubros.Delete();
                        MessageBox.Show(Class2CodigoCentral.mensajeError);

                        Index();

                    }
                }
                else
                {
                    MessageBox.Show("Debes seleccionar una fila para Eliminar");
                }
            }
            catch
            {
                MessageBox.Show("No existe ningún elemento en la lista");
            }

        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnImprimir_Click(object sender, EventArgs e)
        {





        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
            }
            catch
            {
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                //dataGridView2.DataSource = DListaProductosProveedores.IndexListaproductosXproveedor();
            }
            catch
            {
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                //dataGridView2.DataSource = DListaProductosProveedores.IndexListaproductosXproveedor();
            }
            catch
            {
            }
        }

        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                //dataGridView2.DataSource = DListaProductosProveedores.IndexListaproductosXproveedor();
            }
            catch
            {
            }
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                //dataGridView2.DataSource = DListaProductosProveedores.IndexListaproductosXproveedor();
            }
            catch
            {
            }
        }

        private void dataGridView1_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                //dataGridView2.DataSource = DListaProductosProveedores.IndexListaproductosXproveedor();
            }
            catch
            {
            }
        }

        private void radioButtonNombre_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void radioButtonCuit_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void radioButtonDireccion_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void radioButtonEmail_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void radioButtonTel_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 1)
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                Class2CodigoCentral.RubroName = this.dataGridView1.CurrentRow.Cells["NOMBRE"].Value.ToString();
                

                FrmProveedoresDetalles details = new FrmProveedoresDetalles();
                details.ShowDialog();
            }
            else
            {
                MessageBox.Show("Debes seleccionar una fila para editar");
            }
            Index();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 1)
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                FrmListaProductosProveedor lista = new FrmListaProductosProveedor();

                lista.ShowDialog();
            }
            else
            {
                MessageBox.Show("Debes seleccionar una fila para editar");
            }
            Index();
        }



        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Class2CodigoCentral.idProveedor = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                //dataGridView2.DataSource = DListaProductosProveedores.IndexListaproductosXproveedor();
            }
            catch
            {
            }
        }


    }
}
