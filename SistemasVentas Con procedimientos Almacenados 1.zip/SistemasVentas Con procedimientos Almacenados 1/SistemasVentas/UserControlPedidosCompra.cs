﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class UserControlPedidosCompra : UserControl
    {
        public UserControlPedidosCompra()
        {
            Class2CodigoCentral.registros();
            Class2CodigoCentral.PageNumber = 1;
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

        }
        private void diseño()
        {
            try
            {

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[10].Visible = false;
                dataGridView1.Columns[11].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                dataGridView1.Columns[12].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            }
            catch { }
        }

        private void Index()
        {

            if (comboBox1.SelectedIndex == 0)
            {
                ClassAbastecimiento.PaginateFull();
                dataGridView1.DataSource = ClassAbastecimiento.IndexAbastecimientoFull();
                BtnMarcar.Enabled = false;
                BtnEliminar.Enabled = false;
            }
            if (comboBox1.SelectedIndex == 1)
            {
                ClassAbastecimiento.PaginateFacturado();
                dataGridView1.DataSource = ClassAbastecimiento.IndexAbastecimientoFacturado();
                BtnMarcar.Enabled = false;
                BtnEliminar.Enabled = false;
            }

            if (comboBox1.SelectedIndex == 2)
            {
                ClassAbastecimiento.PaginatePorFacturar();
                dataGridView1.DataSource = ClassAbastecimiento.IndexAbastecimientoPorFacturar();
                BtnMarcar.Enabled = false;
                BtnEliminar.Enabled = true;
                Class2CodigoCentral.PageNumber = 1;

            }
            if (comboBox1.SelectedIndex == 3)
            {
                ClassAbastecimiento.PaginatePorRealizar();
                dataGridView1.DataSource = ClassAbastecimiento.IndexAbastecimientoPorRealizar();
                BtnMarcar.Enabled = true;

                BtnEliminar.Enabled = true;
            }
            if (comboBox1.SelectedIndex == 4)
            {
                ClassAbastecimiento.PaginateRealizado();
                dataGridView1.DataSource = ClassAbastecimiento.IndexAbastecimientoRealizado();
                BtnMarcar.Enabled = false;

                BtnEliminar.Enabled = false;
            }
            diseño();
            this.labelPage.Text = String.Format("Página {0} de {1}", Class2CodigoCentral.PageNumber, Class2CodigoCentral.TotalPage);
        }

        public void Search()
        {
            Class2CodigoCentral.busqueda = textBoxSearch.Text;
            diseño();
            if (comboBox2.SelectedIndex == 0)
            {

                dataGridView1.DataSource = ClassAbastecimiento.SearchAbastecimientoCodPro();
            }
            if (comboBox2.SelectedIndex == 1)
            {
                dataGridView1.DataSource = ClassAbastecimiento.SearchAbastecimientoNomProd();
            }

            if (comboBox2.SelectedIndex == 2)
            {
                dataGridView1.DataSource = ClassAbastecimiento.SearchAbastecimientoNomProv();
            }

            if (comboBox2.SelectedIndex == 3)
            {
                dataGridView1.DataSource = ClassAbastecimiento.SearchAbastecimientoCuitProv();
            }


        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            FrmModuloPedidos compra = new FrmModuloPedidos();
            compra.ShowDialog();
            Index();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class2CodigoCentral.PageNumber = 1;
            Index();
        }

        private void UserControlPedidosCompra_Load(object sender, EventArgs e)
        {
            Index();
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber < Class2CodigoCentral.TotalPage)
            {
                Class2CodigoCentral.PageNumber++;

            }
            Index();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (Class2CodigoCentral.PageNumber > 1)
            {
                Class2CodigoCentral.PageNumber = Class2CodigoCentral.PageNumber - 1;

            }
            Index();
        }
        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dataGridView1.Rows.Count > 1)
                {
                    DialogResult confirmacion = MessageBox.Show("¿Seguro deseas eliminar este pedido?", "Eliminar Pedido",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                    if (confirmacion == DialogResult.OK)
                    {

                        Class2CodigoCentral.idPedido = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                        ClassAbastecimiento.Delete();
                        MessageBox.Show(Class2CodigoCentral.mensajeError);

                        Index();

                    }
                }
                else
                {
                    MessageBox.Show("Debes seleccionar una fila para Eliminar");
                }
            }
            catch
            {
                MessageBox.Show("No existe ningún elemento en la lista");
            }
        }





        private void BtnMarcar_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 1)
            {
                Class2CodigoCentral.idPedido = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID2"].Value.ToString()));
                Class2CodigoCentral.Cantidad = this.dataGridView1.CurrentRow.Cells["CANT"].Value.ToString();

                ClassAbastecimiento.Marcar();
                
               

                Index();


            }
            else
            {
                MessageBox.Show("Debes seleccionar una fila para marcar como REALIZADO");
            }

        }

        private void BtnFacturar_Click(object sender, EventArgs e)
        {
            FrmEmitirCompra factura = new FrmEmitirCompra();
            factura.ShowDialog();
            Index();
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Index();
        }
    }
}
