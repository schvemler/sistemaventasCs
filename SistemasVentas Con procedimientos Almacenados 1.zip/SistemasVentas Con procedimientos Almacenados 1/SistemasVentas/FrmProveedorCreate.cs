﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmProveedorCreate : Form
    {
        public FrmProveedorCreate()
        {
            InitializeComponent();
        }
        private void Asig()
        {
            try
            {
                Class2CodigoCentral.RubroName = textBoxName.Text;

            }
            catch { }
        }
        private void Index()
        {
            dataGridView1.DataSource = ClassRubros.IndexDesc();
        }


        private void BtnSave_Click(object sender, EventArgs e)
        {
            Asig();

            if (Class2CodigoCentral.RubroName == null || Class2CodigoCentral.RubroName == String.Empty)
            {
                MessageBox.Show("FALTÓ COMPLETAR EL CAMPO 'NOMBRE'");
                textBoxName.Focus();
            }
            else
            {
               ClassRubros.Create();

                if (Class2CodigoCentral.conteoErrores == true)
                {
                    MessageBox.Show(Class2CodigoCentral.mensajeError);
                }
                else
                {
                    textBoxName.Text = "";
                    Index();
                    textBoxName.Focus();
                }



            }



        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
            if (e.KeyChar == 13)
            {
                BtnSave.PerformClick();
            }
        }

        



        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmProveedorCreate_Load(object sender, EventArgs e)
        {
            Index();
        }



    }
}

