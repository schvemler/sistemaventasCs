﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmListaProductosProveedor : Form
    {
        public FrmListaProductosProveedor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormListaProductosProveedor_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DListaProductosProveedores.IndexListaDetallesproductosXproveedor();
        }
    }
}
