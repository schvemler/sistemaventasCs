﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace SistemasVentas
{

    public partial class FrmModuloVenta : Form
    {
        public FrmModuloVenta()
        {
            InitializeComponent();
        }
        //public Boolean coma = false;
        public int conteo = 0;
        private void Search()
        {
            
            Class2CodigoCentral.busqueda = textBoxSearch.Text;
            if (comboBox2.SelectedIndex == 0)
            {
                dataGridView1.DataSource = ClassProductos.SearchCodigoVenta();
            }
            if (comboBox2.SelectedIndex == 1)
            {
                dataGridView1.DataSource = ClassProductos.SearchNameVenta();
            }
            try
            {
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[1].Visible = false;

                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            }
            catch { }

        }
        private void Agregar()
        {
            if (dataGridView1.Rows.Count > 1)
            {
                Class2CodigoCentral.ProductName = dataGridView1.CurrentRow.Cells["PRODUCTO"].Value.ToString();
                Class2CodigoCentral.PrecioVenta = dataGridView1.CurrentRow.Cells["PRECIO"].Value.ToString();
                Class2CodigoCentral.RubroNombre = dataGridView1.CurrentRow.Cells["RUBRO"].Value.ToString();
                if (string.IsNullOrEmpty(textBoxCantidad.Text))
                {
                    Class2CodigoCentral.Cantidad = "1,00";
                }
                else
                {
                    Class2CodigoCentral.Cantidad = textBoxCantidad.Text;
                }
                Class2CodigoCentral.ProductCodigo = dataGridView1.CurrentRow.Cells["CODIGO"].Value.ToString();
                Class2CodigoCentral.idProduct = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value.ToString());
                Class2CodigoCentral.idRubro = Convert.ToInt32(dataGridView1.CurrentRow.Cells["IDR"].Value.ToString());
                decimal total = Convert.ToDecimal(Class2CodigoCentral.PrecioVenta.Replace(".", ",")) * Convert.ToDecimal(Class2CodigoCentral.Cantidad.Replace(".", ","));

                dataGridView2.Rows.Add(Class2CodigoCentral.idProduct,
                    Class2CodigoCentral.idRubro,
                    Class2CodigoCentral.ProductCodigo,
                    Class2CodigoCentral.ProductName,
                    Class2CodigoCentral.RubroNombre,
                    Class2CodigoCentral.PrecioVenta,
                    Class2CodigoCentral.Cantidad.Replace(".", ","),
                    Convert.ToString(total));
                textBoxSearch.Focus();
                textBoxCantidad.Text = "";


            }
            else
            {
                textBoxSearch.Text = "";
                textBoxSearch.Focus();
            }

        }
        private void Subtotal()
        {
            try
            {
                if (dataGridView2.Rows.Count > 1)
                {
                    Class2CodigoCentral.subtotal = 0;
                    for (int fila = 1; fila < dataGridView2.Rows.Count; fila++)
                    {
                        decimal precio;
                        precio = Convert.ToDecimal(dataGridView2.Rows[fila - 1].Cells["TOTAL"].Value.ToString());
                        Class2CodigoCentral.subtotal = Class2CodigoCentral.subtotal + precio;
                        textBoxCostoTotal.Text = Convert.ToString(Class2CodigoCentral.subtotal);

                    }
                }
            }
            catch
            {
            
            }
            

        }
        private void ticket()
        {
            FrmTiquet ticket = new FrmTiquet();
            ticket.ShowDialog();
        }
        
        private void ventanapago()
        {
            FrmPago pago = new FrmPago();
            pago.ShowDialog();
        }
        private void Venta()
        {
            if (this.dataGridView2.Rows.Count > 1)
            {
                if (string.IsNullOrEmpty(Class2CodigoCentral.paga.Replace(".", "")))
                {
                    MessageBox.Show("NO HA INGRESADO EL TOTAL ABONADO");
                    textBoxSearch.Text = "";
                    textBoxSearch.Enabled = true;
                    textBoxSearch.Focus();

                }
                else
                {
                    Class2CodigoCentral.FacturaDetails = "VENTA DE PRODUCTOS";

                    if ((Convert.ToDecimal(Class2CodigoCentral.paga.Replace(".", ",")) - Class2CodigoCentral.subtotal) >= 0)
                    {
                        Class2CodigoCentral.compra = false;
                        DFacturas.Create();
                        
                        Class2CodigoCentral.linea = "PRODUCTO                       Precio     Cant.      Sub.Total" + "\n";
                        for (int fila = 1; fila < dataGridView2.Rows.Count; fila++)
                        {
                            Class2CodigoCentral.elemento = dataGridView2.Rows[fila - 1].Cells["PRODUCTO"].Value.ToString();
                            DReportes.EspacioLineaFactura1();
                            Class2CodigoCentral.linea = Class2CodigoCentral.linea + Class2CodigoCentral.elemento + Class2CodigoCentral.espacio;
                            Class2CodigoCentral.elemento = dataGridView2.Rows[fila - 1].Cells["PRECIO"].Value.ToString();

                            DReportes.EspacioLineaFactura2();
                            Class2CodigoCentral.linea = Class2CodigoCentral.linea + Class2CodigoCentral.elemento + Class2CodigoCentral.espacio;
                            Class2CodigoCentral.elemento = dataGridView2.Rows[fila - 1].Cells["CANT"].Value.ToString();

                            DReportes.EspacioLineaFactura2();
                            Class2CodigoCentral.linea = Class2CodigoCentral.linea + Class2CodigoCentral.elemento + Class2CodigoCentral.espacio;
                            Class2CodigoCentral.elemento = dataGridView2.Rows[fila - 1].Cells["TOTAL"].Value.ToString();
                            DReportes.EspacioLineaFactura2();
                            Class2CodigoCentral.linea = Class2CodigoCentral.linea + Class2CodigoCentral.elemento + Class2CodigoCentral.espacio + "\n";
                            Class2CodigoCentral.idProduct = Convert.ToInt32(dataGridView2.Rows[fila-1].Cells["ID"].Value.ToString());
                            Class2CodigoCentral.PrecioProveedor = dataGridView2.Rows[fila-1].Cells["PRECIO"].Value.ToString();
                            Class2CodigoCentral.Cantidad = dataGridView2.Rows[fila-1].Cells["CANT"].Value.ToString();
                            Class2CodigoCentral.idRubro = Convert.ToInt32(dataGridView2.Rows[fila - 1].Cells["IDR"].Value.ToString());
                     
                            Class2CodigoCentral.idFacturas = Class2CodigoCentral.MaxIdFactura;
                           ClassVenta.Create();
                          
                        }
                        Class2CodigoCentral.linea = Class2CodigoCentral.linea + "TOTAL: " + Convert.ToString(Class2CodigoCentral.subtotal) + "\n";
                        Class2CodigoCentral.linea = Class2CodigoCentral.linea + "PAGADO: " + Class2CodigoCentral.paga + "\n";
                        Class2CodigoCentral.linea = Class2CodigoCentral.linea + "CAMBIO: " + Convert.ToString(Convert.ToDecimal(Class2CodigoCentral.paga) - Class2CodigoCentral.subtotal);
                        DReportes.CrearArchivoFactura();
                        DReportes.EscribirlineaFactura();

                        Class2CodigoCentral.costo = Class2CodigoCentral.subtotal;
                        DTickets.Create();
                        buttonGuardar.Enabled = false;
                        buttonQuitarProducto.Enabled = false;
                        ticket();

                        textBoxCantidad.Enabled = false;
                        this.Close();
                       
                    }
                    else
                    {
                        MessageBox.Show("EL TOTAL INGRESADO COMO PAGO ES MENOR AL COSTO DE LA COMPRA");
                        ventanapago();
                        Venta();
                    }


                }
            }
            else
            {
                MessageBox.Show("NO HAY PRODUCTOS EN LA LISTA DE VENTAS");
                textBoxSearch.Text = "";
            }


        }
        private void finalizar()
        {
            if (this.dataGridView2.Rows.Count > 1)
            {
                textBoxCantidad.Enabled = false;
                textBoxSearch.Enabled = false;
                dataGridView1.Enabled = false;
                Subtotal();
                ventanapago();
                Venta();
            }
            else
            {
                MessageBox.Show("NO HAY PRODUCTOS EN LA LISTA DE VENTAS");
                textBoxSearch.Text = "";
                textBoxSearch.Focus();
            }
        }
        private void radioButtonCodigo_CheckedChanged(object sender, EventArgs e)
        {
            Search();
            Subtotal();
        }
        private void FrmModuloVenta_Load(object sender, EventArgs e)
        {
            //dataGridView2.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            //dataGridView2.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            //dataGridView2.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            //dataGridView2.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            //dataGridView2.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            //dataGridView2.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            //dataGridView2.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Class2CodigoCentral.subtotal = 0;
            Class2CodigoCentral.vendido = false;
            Search();
            Subtotal();
            comboBox2.SelectedIndex = 0;
        }
        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search();
            Subtotal();
        }
        private void textBoxSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                Class2CodigoCentral.multiventa = false;
                this.Close();
            }
            if (e.KeyChar == 13)
            {
                dataGridView1.Focus();
                Agregar();
                Subtotal();
                textBoxSearch.Text = "";
            }
            if (e.KeyChar == 42)
            {
                buttonGuardar.PerformClick();


            }
            if (e.KeyChar == 43)
            {
                e.Handled = true;
                textBoxCantidad.Enabled = true;
                dataGridView1.Focus();
                textBoxCantidad.Focus();
            }
            else
            {
                e.Handled = false;
            }

        }
        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                textBoxCantidad.Focus();
            }
        }
        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                textBoxCantidad.Focus();
            }
        }
        private void textBoxCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
               
                

            }

            if (e.KeyChar == 8)
            {
               
                textBoxCantidad.Text = "";
            }

            if (e.KeyChar == 13)
            {

                try 
                {
                    Convert.ToDecimal(textBoxCantidad.Text.Replace(".", ","));
                    Agregar();
                    Subtotal();
                    textBoxCantidad.Enabled = false;
                }
                catch 
                {
                    MessageBox.Show("Ha introducido un valor no válido");
                    textBoxCantidad.Focus();
                }
             
                
                
            }


        }
        private void buttonQuitarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView2.Rows.Count > 0)
                {
                    this.dataGridView2.Rows.Remove(this.dataGridView2.Rows[this.dataGridView2.CurrentRow.Index]);

                }

                else
                {

                }

            }
            catch { }
        }
        private void buttonGuardar_Click(object sender, EventArgs e)
        {
            Class2CodigoCentral.multiventa = true;
            finalizar();
            
        }
       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class2CodigoCentral.multiventa = false;
            this.Close();
        }
    }
}
