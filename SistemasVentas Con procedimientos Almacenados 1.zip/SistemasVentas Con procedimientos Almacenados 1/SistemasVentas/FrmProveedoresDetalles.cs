﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmProveedoresDetalles : Form
    {
        public FrmProveedoresDetalles()
        {
            InitializeComponent();
        }
        //IndexListaDetallesproductosXproveedor
        public Boolean coma = false;

        public int conteo = 0;

        public void index()
        {

            dataGridView2.DataSource = DListaProductosProveedores.IndexListaDetallesproductosXproveedor();
            //dataGridView1.Columns[0].Visible = false;
        }
        public void Search()
        {
            if (radioButtonNombre.Checked == true)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = DListaProductosProveedores.SearchNameVincular();
                //dataGridView1.Columns[0].Visible = false;
                ClassProductos.Paginate();

            }
            if (radioButtonMarca.Checked == true)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = DListaProductosProveedores.SearchMarcaVincular();
                //dataGridView1.Columns[0].Visible = false;
                ClassProductos.Paginate();

            }
            if (radioButtonCodigo.Checked == true)
            {
                Class2CodigoCentral.busqueda = textBoxSearch.Text;
                dataGridView1.DataSource = DListaProductosProveedores.SearchCodigoVincular();
                //dataGridView1.Columns[0].Visible = false;
                ClassProductos.Paginate();
            }


        }
        public void update()
        {
            try
            {
                DialogResult dialogResult = MessageBox.Show("HA SELECIONADO 'ACTUALIZAR INFORMACIÓN' ¿DESEA REALIZAR ESTA OPERACIÓN?", "ACTUALIZAR PRECIO", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView2.CurrentRow.Cells["ID"].Value.ToString()));
                    Class2CodigoCentral.PrecioProveedor = textBox1.Text;
                    DListaProductosProveedores.Update();
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do something else
                }

            }
            catch
            {
                MessageBox.Show("NO SE PUEDE REALIZAR ESTA OPERACIÓN");
            }
        }
        public void Delete()
        {

            try
            {
                DialogResult dialogResult = MessageBox.Show("A SELECCIONADO LA OPCIÓN DE ELIMINAR UN PRODUCTO VINCULADO CON ESTE PROVEEDOR ¿ESTÁ SEGURO DE REALIZAR LA OPERACIÓN?", "DESVINCULAR PRODUCTO", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView2.CurrentRow.Cells["ID"].Value.ToString()));
                    DListaProductosProveedores.Delete();
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do something else
                }

            }
            catch
            {
                MessageBox.Show("NO SE PUEDE REALIZAR ESTA OPERACIÓN");
            }


        }
        public void SearchIfExist()
        {
            if (this.dataGridView1.Rows.Count > 0)
            {

                if (string.IsNullOrEmpty(textBox3.Text))
                {
                    Class2CodigoCentral.PrecioProveedor = "0.00";
                }
                else
                {
                    Class2CodigoCentral.PrecioProveedor = textBox3.Text;
                }

                Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                DListaProductosProveedores.SearchIfExist();
                if (Class2CodigoCentral.existencia == true)
                {
                    MessageBox.Show(Class2CodigoCentral.mensajeError);
                }
                else
                {
                    try
                    {
                        DListaProductosProveedores.CreateAgregar();
                    }
                    catch
                    {
                        MessageBox.Show("No se pudo realizar la operaciòn, verifique que los parametros estèn bien escritos");
                    }
                    index();

                }

            }
            else
            {
                MessageBox.Show("Debes seleccionar una fila para editar");
            }


        }
        private void FrmProveedoresDetalles_Load(object sender, EventArgs e)
        {

            Search();
            textBoxSearch.Focus();
            labelId.Text = Convert.ToString(Class2CodigoCentral.idProveedor);
            labelNombre.Text = Class2CodigoCentral.RubroName;
            labelCuit.Text = Class2CodigoCentral.ProveedorCuit;
            labelDireccion.Text = Class2CodigoCentral.ProveedorDireccion;
            labelTel.Text = Class2CodigoCentral.ProveedorTelefono;
            labelEmail.Text = Class2CodigoCentral.ProveedorEmail;
            index();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonCodigo_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonMarca_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void radioButtonNombre_CheckedChanged(object sender, EventArgs e)
        {
            Search();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Delete();
            index();


        }
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
            else
            {
                if (e.KeyChar == 46 && coma == true)
                {
                    e.Handled = true;
                }
                else
                {
                    if (conteo > 1)
                    {
                        e.Handled = true;
                    }
                    else
                    {

                        if (coma == true)
                        {
                            conteo++;
                        }
                        e.Handled = false;
                    }

                }

            }

            if (e.KeyChar == 46)
            {
                coma = true;
            }




            if (e.KeyChar == 8)
            {
                coma = false;
                conteo = 0;
                textBox3.Text = "";
            }

            if (e.KeyChar == 13)
            {
                SearchIfExist();
                coma = false;
                conteo = 0;
                textBox3.Text = "";

                textBoxSearch.Focus();
            }



        }
        private void textBoxSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
            if (e.KeyChar == 13)
            {
                coma = false;
                conteo = 0;
                textBox3.Text = "";
                textBox3.Focus();
            }
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
            else
            {
                if (e.KeyChar == 46 && coma == true)
                {
                    e.Handled = true;
                }
                else
                {
                    if (conteo > 1)
                    {
                        e.Handled = true;
                    }
                    else
                    {

                        if (coma == true)
                        {
                            conteo++;
                        }
                        e.Handled = false;
                    }

                }

            }

            if (e.KeyChar == 46)
            {
                coma = true;
            }




            if (e.KeyChar == 8)
            {
                coma = false;
                conteo = 0;
                textBox3.Text = "";
            }

            if (e.KeyChar == 13)
            {

                coma = false;
                conteo = 0;
                textBox3.Text = "";

                textBox1.Visible = false;
                update();
                index();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            coma = false;
            conteo = 0;
            textBox1.Visible = true;
            textBox1.Focus();

        }
    }
}
