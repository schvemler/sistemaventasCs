﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace SistemasVentas
{
    class ClassVenta
    {
        public ClassVenta()
        {
        }
        public static MySqlConnection conectarbase = new MySqlConnection();
        public static void Conectar()
        {
            conectarbase.ConnectionString = Class1Coneccion.DataBase;

            conectarbase.Open();
        }
        public static void Desconectar()
        {
            conectarbase.Close();
        }
        public static void Create()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {

                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "VentasCreate";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProductid = new MySqlParameter();
                ParProductid.ParameterName = "ProcedureProductid";
                ParProductid.MySqlDbType = MySqlDbType.Int32;
                ParProductid.Value = Class2CodigoCentral.idProduct;
                MySqlComando.Parameters.Add(ParProductid);

                MySqlParameter ParFacturasid = new MySqlParameter();
                ParFacturasid.ParameterName = "ProcedureIdrubro";
                ParFacturasid.MySqlDbType = MySqlDbType.Int32;
                ParFacturasid.Value = Class2CodigoCentral.idRubro;
                MySqlComando.Parameters.Add(ParFacturasid);

                MySqlParameter ParCantidad = new MySqlParameter();
                ParCantidad.ParameterName = "ProcedureCantidad";
                ParCantidad.MySqlDbType = MySqlDbType.VarChar;
                ParCantidad.Size = Class2CodigoCentral.Cantidad.Length;
                ParCantidad.Value = Class2CodigoCentral.Cantidad.Replace(",", ".");
                MySqlComando.Parameters.Add(ParCantidad);

                MySqlParameter ParPrecio = new MySqlParameter();
                ParPrecio.ParameterName = "ProcedurePrecio";
                ParPrecio.MySqlDbType = MySqlDbType.VarChar;
                ParPrecio.Size = Class2CodigoCentral.PrecioProveedor.Length;
                ParPrecio.Value = Class2CodigoCentral.PrecioProveedor.Replace(",", ".");
                MySqlComando.Parameters.Add(ParPrecio);

                MySqlComando.ExecuteNonQuery();


            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
        public static void PaginateTodas()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "VentasPaginateTodas";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }



        }
        public static DataTable IndexTodas()
        {
            DataTable TablaDatos = new DataTable("ProductIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "ProductIndex";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
           
        }
        public static void PaginateVentas()
        {
            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "VentasPaginateVentas";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "ProcedureLongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);

                MySqlParameter ParTotalPaginas = new MySqlParameter();
                ParTotalPaginas.ParameterName = "ProcedureTotalPage";
                ParTotalPaginas.MySqlDbType = MySqlDbType.Float;
                ParTotalPaginas.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParTotalPaginas);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.TotalPage = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureTotalPage"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }
        }      
        public static DataTable IndexVentas()
        {
            DataTable TablaDatos = new DataTable("VentasIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "VentasIndex";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParPageNumber = new MySqlParameter();
                ParPageNumber.ParameterName = "PageNumber";
                ParPageNumber.MySqlDbType = MySqlDbType.Int32;
                ParPageNumber.Value = Class2CodigoCentral.PageNumber;
                MySqlComando.Parameters.Add(ParPageNumber);

                MySqlParameter ParLongPage = new MySqlParameter();
                ParLongPage.ParameterName = "LongPage";
                ParLongPage.MySqlDbType = MySqlDbType.Int32;
                ParLongPage.Value = Class2CodigoCentral.LongPage;
                MySqlComando.Parameters.Add(ParLongPage);



                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
            
        }
        public static DataTable IndexFacturacion()
        {
            DataTable TablaDatos = new DataTable("VentasIndex");
            MySqlConnection MySqlConexion = new MySqlConnection();
            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "VentasIndexFacturacion";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParProcedureIdFactura = new MySqlParameter();
                ParProcedureIdFactura.ParameterName = "ProcedureIdFactura";
                ParProcedureIdFactura.MySqlDbType = MySqlDbType.Int32;
                ParProcedureIdFactura.Value = Class2CodigoCentral.idFacturas;
                MySqlComando.Parameters.Add(ParProcedureIdFactura);

                MySqlComando.ExecuteNonQuery();

                MySqlDataAdapter SqlAdaptadorDatos = new MySqlDataAdapter(MySqlComando);
                SqlAdaptadorDatos.Fill(TablaDatos);
            }

            catch (Exception ex)
            {
                TablaDatos = null;
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado SystemIndex " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }

            return TablaDatos;
        }   
        public static void Conteo()
        {


            MySqlConnection MySqlConexion = new MySqlConnection();

            try
            {
                MySqlConexion.ConnectionString = Class1Coneccion.DataBase;
                MySqlConexion.Open();

                MySqlCommand MySqlComando = new MySqlCommand();
                MySqlComando.Connection = MySqlConexion;
                MySqlComando.CommandText = "VentasConteoTotal";
                MySqlComando.CommandType = CommandType.StoredProcedure;

                MySqlParameter ParConteoTotal = new MySqlParameter();
                ParConteoTotal.ParameterName = "ProcedureConteoTotal";
                ParConteoTotal.MySqlDbType = MySqlDbType.Float;
                ParConteoTotal.Direction = ParameterDirection.Output;
                MySqlComando.Parameters.Add(ParConteoTotal);

                MySqlComando.ExecuteNonQuery();

                Class2CodigoCentral.totalventas = Convert.ToInt32((float)MySqlComando.Parameters["ProcedureConteoTotal"].Value);
            }

            catch (Exception ex)
            {
                throw new Exception("Error al intentar ejecutar el procedimiento almacenado Tamañosistemas. " + ex.Message, ex);
            }

            finally
            {
                if (MySqlConexion.State == ConnectionState.Open)
                {
                    MySqlConexion.Close();
                }
            }


        }
    }
}
