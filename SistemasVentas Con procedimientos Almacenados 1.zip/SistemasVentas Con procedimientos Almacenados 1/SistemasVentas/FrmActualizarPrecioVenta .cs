﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmActualizarPrecioVenta : Form
    {
        public FrmActualizarPrecioVenta()
        {
            InitializeComponent();
        }
        public Boolean coma = false;

        public int conteo = 0;

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
            else
            {
                if (e.KeyChar == 46 && coma == true)
                {
                    e.Handled = true;
                }
                else
                {
                    if (conteo > 1)
                    {
                        e.Handled = true;
                    }
                    else
                    {

                        if (coma == true)
                        {
                            conteo++;
                        }
                        e.Handled = false;
                    }

                }

            }

            if (e.KeyChar == 46)
            {
                coma = true;
            }




            if (e.KeyChar == 8)
            {
                coma = false;
                conteo = 0;
                textBox1.Text = "";
            }

            if (e.KeyChar == 13)
            {
                Class2CodigoCentral.PrecioVenta = textBox1.Text;
                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    Class2CodigoCentral.PrecioVenta = "0.00";
                }
                if (textBox1.Text == ".")
                {
                    Class2CodigoCentral.PrecioVenta = "0.00";
                }

                this.Close();
            }

        }

        private void FrmActualizarPrecioVenta_Load(object sender, EventArgs e)
        {

        }
    }
}
