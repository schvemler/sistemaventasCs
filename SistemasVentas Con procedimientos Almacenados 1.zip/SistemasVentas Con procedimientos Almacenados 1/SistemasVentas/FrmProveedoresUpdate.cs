﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmProveedoresUpdate : Form
    {
        public FrmProveedoresUpdate()
        {
            InitializeComponent();
        }
        private void Asig()
        {
            try
            {
                Class2CodigoCentral.RubroName = textBoxName.Text;
               

            }
            catch { }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            Asig();


            if (Class2CodigoCentral.RubroName == null || Class2CodigoCentral.RubroName == String.Empty)
            {
                MessageBox.Show("FALTÓ COMPLETAR EL CAMPO 'NOMBRE'");
                textBoxName.Focus();
            }
            else
            {
               ClassRubros.Update();
                MessageBox.Show(Class2CodigoCentral.mensajeError);
                if (Class2CodigoCentral.conteoErrores == false)
                {
                    this.Close();
                }
            }



        }
        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }

            if (e.KeyChar == 13)
            {
                BtnSave.PerformClick();
            }
        }

       


        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FrmProveedoresUpdate_Load(object sender, EventArgs e)
        {
            textBoxName.Text = Class2CodigoCentral.RubroName;
           
        }
    }
}
