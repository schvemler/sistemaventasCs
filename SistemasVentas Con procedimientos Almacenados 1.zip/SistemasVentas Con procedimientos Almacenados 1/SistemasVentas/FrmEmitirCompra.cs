﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SistemasVentas
{
    public partial class FrmEmitirCompra : Form
    {
        public FrmEmitirCompra()
        {
            InitializeComponent();
        }

        public void Index()
        {
            Class2CodigoCentral.busqueda = "";
            dataGridView1.DataSource = ClassAbastecimiento.IndexAbastecimientoPorFacturar();
        }

        private void buttonGenerador_Click(object sender, EventArgs e)
        {
            buttonGuardarFullList.Enabled = true;
            buttonGuardar.Enabled = true;
            buttonCancelar.Enabled = false;
            Class2CodigoCentral.FacturaDetails = "REPOSICIÓN DE PRODUCTOS";
            Class2CodigoCentral.compra = true;
            DFacturas.Create();
            
            //MessageBox.Show("SEA HA GENERADO LA FACTURA Nº" + Convert.ToString(Class2CodigoCentral.MaxIdFactura));
            //Class2CodigoCentral.idFacturas = Class2CodigoCentral.MaxIdFactura;
            labelNumero.Text = Convert.ToString(Class2CodigoCentral.idFacturas);
            labelDetalles.Text = Class2CodigoCentral.FacturaDetails;


        }

        private void buttonGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dataGridView1.Rows.Count > 0)
                {
                    Class2CodigoCentral.idPedido = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID"].Value.ToString()));
                    Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["ID2"].Value.ToString()));
                    Class2CodigoCentral.Cantidad = this.dataGridView1.CurrentRow.Cells["CANT"].Value.ToString();
                    Class2CodigoCentral.PrecioProveedor = this.dataGridView1.CurrentRow.Cells["PRECIO.UNID"].Value.ToString();
                    Class2CodigoCentral.compra = true;
                    ClassAbastecimiento.Facturar();
                    Class2CodigoCentral.idFacturas = Class2CodigoCentral.MaxIdFactura;
                   ClassVenta.Create();
                    Index();
                }
            }
            catch
            {
                MessageBox.Show("No existe ningún elemento en la lista");
            }
        }

        private void FrmEmitirCompra_Load(object sender, EventArgs e)
        {
            Index();
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonGuardarFullList_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dataGridView1.Rows.Count > 0)
                {
                    for (int fila = 1; fila < dataGridView1.Rows.Count; fila++)
                    {
                        Class2CodigoCentral.idPedido = (Convert.ToInt32(this.dataGridView1.Rows[fila - 1].Cells["ID"].Value.ToString()));
                        Class2CodigoCentral.idProduct = (Convert.ToInt32(this.dataGridView1.Rows[fila - 1].Cells["ID2"].Value.ToString()));
                        Class2CodigoCentral.Cantidad = this.dataGridView1.Rows[fila - 1].Cells["CANT"].Value.ToString();
                        Class2CodigoCentral.PrecioProveedor = this.dataGridView1.Rows[fila - 1].Cells["PRECIO.UNID"].Value.ToString();
                        Class2CodigoCentral.compra = true;
                        ClassAbastecimiento.Facturar();
                        Class2CodigoCentral.idFacturas = Class2CodigoCentral.MaxIdFactura;
                       ClassVenta.Create();
                    }

                }
                MessageBox.Show(Class2CodigoCentral.mensajeError);
                this.Close();
            }

            catch
            {
                MessageBox.Show(Class2CodigoCentral.mensajeError);
            }

        }
    }
}
